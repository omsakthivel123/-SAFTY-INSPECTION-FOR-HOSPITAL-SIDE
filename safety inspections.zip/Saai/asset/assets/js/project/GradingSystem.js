$(document).ready(function () {
	$("#InstutionName").on("change", function () {
		var InstutionName = $("#InstutionName").val();
		$("#Course_type").on("change", function () {
			var Course_type = $("#Course_type").val();
			$("#DepartmentName").on("change", function () {
				var DepartmentName = $("#DepartmentName").val();
				$("#Course_name").on("change", function () {
					var Course_name = $("#Course_name").val();
					$("#Batch").on("change", function () {
						var Batch = $("#Batch").val();
						$("#Semesters").on("change", function () {
							var Semesters = $("#Semesters").val();

							$.ajax({
								type: "POST",
								url: baseurl + "GradingSystem/get_subject",
								data: {
									InstutionName: InstutionName,
									Course_type: Course_type,
									DepartmentName: DepartmentName,
									Course_name: Course_name,
									Batch: Batch,
									Semesters: Semesters,
								},
								success: function (response) {
									var responseData = JSON.parse(response);

									var subject_name = { "": "Select Semester" }; // Initial dropdown options

									for (var i = 0; i < responseData.length; i++) {
										var DName = responseData[i];
										subject_name[DName.SubjectName] = DName.SubjectName;
									}
									// Update the dropdown with the new options
									$("#SubjectName").empty(); // Clear existing options
									$.each(subject_name, function (key, value) {
										$("#SubjectName").append(
											$("<option></option>").attr("value", key).text(value)
										);
									});
								},
								error: function (xhr, status, error) {
									// Handle error response here
									console.error(
										"Error occurred while sending selected value to the controller."
									);
								},
							});
						});
					});
				});
			});
		});
	});
});

$(document).ready(function () {
	$("#InstutionName").on("change", function () {
		var InstutionName = $("#InstutionName").val();
		$("#Course_type").on("change", function () {
			var Course_type = $("#Course_type").val();
			$("#DepartmentName").on("change", function () {
				var DepartmentName = $("#DepartmentName").val();
				$("#Course_name").on("change", function () {
					var Course_name = $("#Course_name").val();
					$("#Batch").on("change", function () {
						var Batch = $("#Batch").val();
						$("#Semesters").on("change", function () {
							var Semesters = $("#Semesters").val();
							$("#Section").on("change", function () {
								var Section = $("#Section").val();
								$("#ExamCategory").on("change", function () {
									var ExamCategory = $("#ExamCategory").val();
									$("#SubjectName").on("change", function () {
										var SubjectName = $("#SubjectName").val();

										$.ajax({
											type: "POST",
											url: baseurl + "GradingSystem/get_subject_details",
											data: {
												InstutionName: InstutionName,
												Course_type: Course_type,
												DepartmentName: DepartmentName,
												Course_name: Course_name,
												Batch: Batch,
												Semesters: Semesters,
												Section: Section,
												SubjectName: SubjectName,
												ExamCategory: ExamCategory,
											},
											success: function (response) {
												var responseData = JSON.parse(response);
												var get_sub_details = responseData.get_sub_details;
												var get_student = responseData.get_student;
												// var get_student_attendance = responseData.get_student_attendance;
												var get_exam_date = responseData.get_exam_date;

												// Populate form fields
												var Category = get_sub_details[0].Category;
												var Credits = get_sub_details[0].Credits;
												var Qualifying_Grade =
													get_sub_details[0].QualifyingGrade;

												$("#Category").val(Category);
												$("#Credits").val(Credits);
												$("#Qualifying_Grade").val(Qualifying_Grade);

												// Populate table rows

												//exam date

												var get_student_attendance =
													responseData.get_student_attendance;
												console.log(get_student_attendance);

												var examdate = get_exam_date[0].ExamDate;

												let providedDate = new Date(examdate); // 'date' should be replaced with your actual date string or date object

												// Calculate the difference in days between the provided date and '2024-07-01'
												let differenceInDays = Math.floor(
													(providedDate - new Date("2024-07-01")) /
														(1000 * 3600 * 24)
												);

												let dayFormat = `DAY_${differenceInDays + 1}`; // Adding 1 to convert zero-based to one-based index

												// alert(get_exameam_date)

												$.each(get_student_attendance, function (index, item) {
													// Assuming dayFormat is defined dynamically based on index, e.g., DAY_1, DAY_2, ...
													var dayFormat = "DAY_" + (index + 1); // Assuming index starts from 0

													var get_exameam_date = item[dayFormat]; // Access the specific day field for the current item

													// Determine if the current day's attendance is 'A'
													var isAbsent = get_exameam_date === "A";

													// Set readonly and value based on condition
													var readonlyAttribute = isAbsent ? "readonly" : "";
													var markValue = isAbsent ? "0" : ""; // Set to '0' if absent, empty otherwise

													// Constructing the row dynamically
													var row = `<tr data-student-id="${
														item.Student_Id
													}" data-staff-name="${item.Name}">
											<td><input type="checkbox" class="student-checkbox" id="checkbox-${
												item.Student_Id
											}" name="student-checkbox"></td>
											<td>${index + 1}</td>
											<td>${item.CourseType}</td>
											<td>${item.DepartmentName}</td>
											<td>${item.Exam_Registration_No}</td>
											<td>${item.StudentName}</td>
											<td>${item.Section}</td>
											<td>${item.Batch}</td>
											<td>${item.Semester}</td>
											<td>${ExamCategory}</td>
											<td class="md-2">
												<input type="text" id="Mark-${
													item.Student_Id
												}" name="Mark" class="form-control md-3" style="width: 200px;" value="${markValue}" ${readonlyAttribute}>
											</td>
											<td>${get_exameam_date}</td>
											<td>
												<a class="course_mentor_edit" data-student-id="${
													item.Student_Id
												}"><i class='fas fa-edit' style='color: info; background-color: transparent;'></i></a>&nbsp;&nbsp;&nbsp;
												<a class="course_mentor_delete" data-student-id="${
													item.Student_Id
												}"><i class='fas fa-trash' style='color: red; background-color: transparent;'></i></a>&nbsp;&nbsp;&nbsp;
											</td>
										</tr>`;

													$("#student-mark-entry tbody").append(row);
												});

												// Click event handler for Select All button
												$("#select_mark").click(function () {
													// Check if the button is to select or deselect all
													var selectAll = $(this).text() === "Select All";

													// Update text based on current state
													$(this).text(
														selectAll ? "Deselect All" : "Select All"
													);

													// Toggle all checkboxes
													$(".student-checkbox").prop("checked", selectAll);
												});

												$("#update_marks").on("click", function () {
													var InstutionName = $("#InstutionName").val();
													var Course_type = $("#Course_type").val();
													var DepartmentName = $("#DepartmentName").val();
													var Course_name = $("#Course_name").val();
													var Batch = $("#Batch").val();
													var Semesters = $("#Semesters").val();
													var Section = $("#Section").val();
													var SubjectName = $("#SubjectName").val();
													var ExamCategory = $("#ExamCategory").val();
													var Category = $("#Category").val();
													var Credits = $("#Credits").val();
													var Qualifying_Grade = $("#Qualifying_Grade").val();
													var Mark = $(this).val();
													Category;

													// Array to store table row data
													var tableDataArray = [];

													// Iterate over each table row
													$("#student-mark-entry tbody tr").each(function () {
														var rowData = {
															Exam_Registration_No: $(this)
																.find("td:eq(4)")
																.text()
																.trim(),
															StudentName: $(this)
																.find("td:eq(5)")
																.text()
																.trim(),
															Mark: $(this).find('input[name="Mark"]').val(),
															Attendance: $(this)
																.find("td:eq(11)")
																.text()
																.trim(),
														};

														// Push rowData into array
														tableDataArray.push(rowData);
													});

													// AJAX request
													$.ajax({
														url: baseurl + "GradingSystem/update", // Replace with your actual endpoint URL
														type: "POST",
														data: {
															InstutionName: InstutionName,
															Course_type: Course_type,
															DepartmentName: DepartmentName,
															Course_name: Course_name,
															Batch: Batch,
															Semesters: Semesters,
															Section: Section,
															SubjectName: SubjectName,
															ExamCategory: ExamCategory,
															Category: Category,
															Credits: Credits,
															Qualifying_Grade: Qualifying_Grade,
															tableDataArray: tableDataArray,
														},
														success: function (response) {
															var responseData = JSON.parse(response);

															if (responseData == "SAVE") {
																Swal.fire({
																	title: "Good job!",
																	text: "The assignment of the Student Marks has been completed successfully.",
																	icon: "success",
																	confirmButtonText: "OK",
																}).then((result) => {
																	if (result.isConfirmed) {
																		window.location.href =
																			baseurl + "GradingSystem";
																	}
																});
															} else if (responseData == "ALREADY") {
																Swal.fire({
																	title: "Oops!",
																	text: "The Student Marks has already been assigned and cannot be reassigned.",
																	icon: "error",
																	confirmButtonText: "OK",
																}).then((result) => {
																	if (result.isConfirmed) {
																		window.location.href =
																			baseurl + "GradingSystem";
																	}
																});
															}
														},
														error: function (xhr, status, error) {
															// Handle error
															console.error("Error sending data:", error);
														},
													});
												});
											},

											error: function (xhr, status, error) {
												// Handle error response here
												console.error(
													"Error occurred while sending selected value to the controller."
												);
											},
										});
									});
								});
							});
						});
					});
				});
			});
		});
	});
});

$(document).ready(function () {
	$("#InstutionName").on("change", function () {
		var InstutionName = $("#InstutionName").val();
		$("#Course_type").on("change", function () {
			var Course_type = $("#Course_type").val();
			$("#DepartmentName").on("change", function () {
				var DepartmentName = $("#DepartmentName").val();
				$("#Course_name").on("change", function () {
					var Course_name = $("#Course_name").val();
					$("#Batch").on("change", function () {
						var Batch = $("#Batch").val();
						$("#Semesters").on("change", function () {
							var Semesters = $("#Semesters").val();
							$("#Section").on("change", function () {
								var Section = $("#Section").val();
								$("#SubjectName").on("change", function () {
									var SubjectName = $("#SubjectName").val();

									$.ajax({
										type: "POST",
										url: baseurl + "GradingSystem/get_subject",
										data: {
											InstutionName: InstutionName,
											Course_type: Course_type,
											DepartmentName: DepartmentName,
											Course_name: Course_name,
											Batch: Batch,
											Semesters: Semesters,
											Section: Section,
											SubjectName: SubjectName,
										},
										success: function (response) {
											var responseData = JSON.parse(response);

											var Category = responseData[0].Category;
											var Credits = responseData[0].Credits;
											var Qualifying_Grade = responseData[0].QualifyingGrade;

											$("#Category").val(Category);
											$("#Credits").val(Credits);
											$("#Qualifying_Grade").val(Qualifying_Grade);
										},
										error: function (xhr, status, error) {
											// Handle error response here
											console.error(
												"Error occurred while sending selected value to the controller."
											);
										},
									});
								});
							});
						});
					});
				});
			});
		});
	});
});

$(document).ready(function () {
	$("#mark_report").hide();

	$("#Student_mark").on("click", function () {
		var InstutionName = $("#InstutionName").val();
		var Course_type = $("#Course_type").val();
		var DepartmentName = $("#DepartmentName").val();
		var Course_name = $("#Course_name").val();
		var Batch = $("#Batch").val();
		var Semesters = $("#Semesters").val();
		var Section = $("#Section").val();
		var SubjectName = $("#SubjectName").val();

		$.ajax({
			type: "POST",
			url: baseurl + "GradingSystem/report",
			data: {
				InstutionName: InstutionName,
				Course_type: Course_type,
				DepartmentName: DepartmentName,
				Course_name: Course_name,
				Batch: Batch,
				Semesters: Semesters,
				Section: Section,
				SubjectName: SubjectName,
			},
			success: function (response) {
				var responseData = JSON.parse(response);
				var row = "";
				$("#mark_report").show();
				$.each(responseData, function (index, item) {
					row += `<tr data-subject-id="${item.SubjectName}">
						<td>${index + 1}</td>
						<td>${item.DepartmentName}</td>
						<td>${item.CourseType}</td>
						<td>${item.CourseName}</td>
						<td>${item.Batch}</td>
						<td>${item.Semester}</td>
						<td>${item.Section}</td>
						<td>${item.Exam_Registration_No}</td>
						<td>${item.StudentName}</td>
						<td>${item.SubjectCode}</td>
						<td>${item.SubjectName}</td>
						<td>${item.Category}</td>
						<td>${item.Credits}</td>
						<td>${item.Qualifying_Grade}</td>
						<td class="${item.Mark === 0 ? "yellow-background" : ""}">${item.Mark}</td>
						<td>${""}</td>
						<td>${""}</td>
						<td>${""}</td>
						<td>
							<a href="#" class="course_mentor_edit" data-student-id="${
								item.Exam_Registration_No
							}"><i class='fas fa-edit' style='color: blue; background-color: transparent;'></i></a>&nbsp;&nbsp;&nbsp;
							<a href="#" class="course_mentor_delete" data-student-id="${
								item.Exam_Registration_No
							}"><i class='fas fa-trash' style='color: red; background-color: transparent;'></i></a>&nbsp;&nbsp;&nbsp;
						</td>
					</tr>`;
				});
				$("#Student_mark_get tbody").append(row);

				// Edit button click event handler
				$(".course_mentor_edit").click(function (event) {
					event.preventDefault();
					var studentId = $(this).data("student-id");
					// Perform edit action with studentId
					// Example: Redirect to edit page or open modal with studentId
					console.log("Edit button clicked for student ID:", studentId);
					// Add your edit functionality here
				});

				// Delete button click event handler
				$(".course_mentor_delete").click(function (event) {
					event.preventDefault();
					var studentId = $(this).data("student-id");
					// Perform delete action with studentId
					// Example: Prompt confirmation and then delete row or perform AJAX delete
					console.log("Delete button clicked for student ID:", studentId);
					// Add your delete functionality here
				});
			},

			error: function (xhr, status, error) {
				console.error(
					"Error occurred while sending selected value to the controller."
				);
			},
		});
	});
});

// get overall report  section start


$(document).ready(function () {

	// $("#").hide();

	$("#overal_report_btn").on("click", function () {

		var InstutionName = $("#InstutionName").val();
		var Course_type = $("#Course_type").val();
		var DepartmentName = $("#DepartmentName").val();
		var Course_name = $("#Course_name").val();
		var Batch = $("#Batch").val();
		var Semesters = $("#Semesters").val();
		var Section = $("#Section").val();
		var ExamCategory = $("#ExamCategory").val();


		$.ajax({
			type: "POST",
			url: baseurl + "GradingSystem/overall_report",
			data: {
				InstutionName: InstutionName,
				Course_type: Course_type,
				DepartmentName: DepartmentName,
				Course_name: Course_name,
				Batch: Batch,
				Semesters: Semesters,
				Section: Section,
				ExamCategory : ExamCategory
				
			},
			success: function (response) {
				var responseData = JSON.parse(response);

				var overal_mark_gets = responseData.overal_mark_gets;
				var semester_exam_subject = responseData.semester_exam_subject;

				// Clear existing rows in the tbody before appending new ones
				$("#semester_subjects tbody").empty();

				$.each(overal_mark_gets, function (index, item) {
					var row = `<tr data-subject-id="${item.SubjectCode}">
						<td>${index + 1}</td>
						<td>${item.ExamCategory}</td>
						<td>${item.SubjectCode}</td>
						<td>${item.SubjectName}</td>
						<td>${item.ExamDate}</td>
					</tr>`;
					
					$("#semester_subjects tbody").append(row);
				});
				// First, collect all unique subject codes
				var uniqueSubjectCodes = [];

				$('#mark_table thead').empty();
				$('#mark_table tbody').empty();

				$.each(semester_exam_subject, function(index, item) {
					if (uniqueSubjectCodes.indexOf(item.SubjectCode) === -1) {
						uniqueSubjectCodes.push(item.SubjectCode);
					}
				});

				// Generate headers dynamically for all unique subject codes
				var headerNames = `<th style="color: whitesmoke">S.No</th>
									<th style="color: whitesmoke" >Exam Registration No</th>
									<th style="color: whitesmoke" >Student Name</th>`;

				$.each(uniqueSubjectCodes, function(index, subjectCode) {
					headerNames += `<th style="color: whitesmoke" >${subjectCode}</th>`;
				});

				// Initialize an object to store rows by student ID
				var rowsByStudent = {};

				// Iterate over each subject in semester_exam_subject array to generate rows
				$.each(overal_mark_gets, function(index, item) {
					var studentId = item.Exam_Registration_No; // Assuming Exam_Registration_No uniquely identifies a student

					if (!rowsByStudent[studentId]) {
						rowsByStudent[studentId] = {
							studentName: item.StudentName,
							marks: {}
						};
					}

					// Add marks for the current subject code
					rowsByStudent[studentId].marks[item.SubjectCode] = item.Mark;
				});

				// Convert rowsByStudent object into HTML rows
				var rows = '';

				$.each(rowsByStudent, function(studentId, studentData) {
					var row = `<tr>
								<td>${Object.keys(rowsByStudent).indexOf(studentId) + 1}</td>
								<td>${studentId}</td>
								<td>${studentData.studentName}</td>`;

					// Loop through uniqueSubjectCodes to add corresponding data for each subject code
					$.each(uniqueSubjectCodes, function(idx, subjectCode) {
						var mark = studentData.marks[subjectCode] || ''; // Get mark or empty string if not available
						row += `<td>${mark}</td>`;
					});

					row += `</tr>`;
					rows += row;
				});

				// Append table headers to the <thead> of the existing table
				$('#mark_table thead').append('<tr>' + headerNames + '</tr>');

				// Append table rows to the <tbody> of the existing table
				$('#mark_table tbody').append(rows);
	
			},
 


	});
});
});

// get overall report  section end



