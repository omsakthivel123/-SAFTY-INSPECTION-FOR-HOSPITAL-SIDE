$(document).ready(function () {
	$("#InstutionName").on("change", function () {
		var InstutionName = $("#InstutionName").val();
		$("#Course_type").on("change", function () {
			var Course_type = $("#Course_type").val();
			$("#DepartmentName").on("change", function () {
				var DepartmentName = $("#DepartmentName").val();
				$("#Course_name").on("change", function () {
					var Course_name = $("#Course_name").val();
					$.ajax({
						type: "POST",
						url: baseurl + "Semester_Attendance/get_semester",
						data: { 
							
							InstutionName: InstutionName, 
							Course_type: Course_type,
							DepartmentName : DepartmentName,
							Course_name : Course_name
						
						},
						success: function (response) {
							var responseData = JSON.parse(response);

							var sem = { "": "Select Semester" }; // Initial dropdown options

							for (var i = 0; i < responseData.length; i++) {
								var DName = responseData[i];
								sem[DName.Semester] = DName.Semester;
							}
							// Update the dropdown with the new options
							$("#Semester").empty(); // Clear existing options
							$.each(sem, function (key, value) {
								$("#Semester").append(
									$("<option></option>").attr("value", key).text(value)
								);
							});
						},
						error: function (xhr, status, error) {
							// Handle error response here
							console.error(
								"Error occurred while sending selected value to the controller."
							);
						},
					});
				});
			});
		});
	});
});


$(document).ready(function () {

	$('#semester-view').hide();

	// Event listener for fetching student list
	$("#get_sem_data").on("click", function () {
		var InstitutionName = $("#InstutionName").val();
        var CourseType = $("#Course_type").val();
        var DepartmentName = $("#DepartmentName").val();
        var Batch = $("#Batch").val();
        var CourseName = $("#Course_name").val();
        var Section = $("#Section").val();
		var Semester = $("#Semester").val();


		$.ajax({
			type: "POST",
			url: baseurl + "Semester_Attendance/get_list",
			data: {
				InstitutionName: InstitutionName,
				CourseType: CourseType,
				DepartmentName: DepartmentName,
				Batch: Batch,
				CourseName: CourseName,
				Section: Section,
				Semester : Semester
			},
			success: function (response) {
				var responseData = JSON.parse(response);

				// Clear previous table data if needed
				$('#sem_stud').empty();

				// Append each row to the table
				$.each(responseData, function(index, item) {

					$('#semester-view').show();
							
					var percentage = item.Total_Present; // Assuming item.Total_Present is a number representing days present
					var per = (percentage / 180) * 100; // Calculate the percentage out of 180 days
					var final = per.toFixed(2) + '%'; 

					var row = `<tr>
						<td>${index + 1}</td>
						<td>${item.StudentId}</td>
						<td>${item.Exam_Registration_No}</td>
						<td>${item.Semester}</td>
						<td>${item.StudentName}</td>
						<td>${item.Total_Present}</td>
						<td>${item.Total_Absent}</td>
						<td>${final}</td>
						<td>${"180"}</td>
						<td>${item.CreatedBy}</td>
					</tr>`;
					$('#sem_stud').append(row);
				});
			}
		});
	});
});
