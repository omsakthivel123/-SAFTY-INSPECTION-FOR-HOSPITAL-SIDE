$(document).ready(function () {
	$("#InstutionName").on("change", function () {
		var selectedValue = $(this).val();
		$.ajax({
			type: "POST",
			url: baseurl + "Student_Attendance/get_course_type",
			data: { selectedValue: selectedValue },
			success: function (response) {
				var responseData = JSON.parse(response);
				var CourseType = { "": "Select Course Type" }; // Initial dropdown options
				// Loop through the response data and add each district to the dropdown options
				for (var i = 0; i < responseData.length; i++) {
					var DName = responseData[i];
					CourseType[DName.CourseType] = DName.CourseType;
				}
				// Update the dropdown with the new options
				$("#Course_type").empty(); // Clear existing options
				$.each(CourseType, function (key, value) {
					$("#Course_type").append(
						$("<option></option>").attr("value", key).text(value)
					);
				});
			},
			error: function (xhr, status, error) {
				// Handle error response here
				console.error(
					"Error occurred while sending selected value to the controller."
				);
			},
		});
	});
});



$(document).ready(function () {
	$("#Course_type").on("change", function () {
		var Course_type = $("#Course_type").val();
		$("#DepartmentName").on("change", function () {
			var Department_Name = $("#DepartmentName").val();
			$.ajax({
				type: "POST",
				url: baseurl + "Student_Attendance/get_batch",
				data: { Course_type: Course_type, Department_Name: Department_Name },
				success: function (response) {
					var responseData = JSON.parse(response);
					var dropdownOptions = { "": "Select Batch" }; // Initial dropdown options

					for (var i = 0; i < responseData.length; i++) {
						var DName = responseData[i];
						dropdownOptions[DName.Batch] = DName.Batch;
					}
					// Update the dropdown with the new options
					$("#Batch").empty(); // Clear existing options
					$.each(dropdownOptions, function (key, value) {
						$("#Batch").append(
							$("<option></option>").attr("value", key).text(value)
						);
					});
					// $("#Batch option:last").prop("selected", true);	
				},
				error: function (xhr, status, error) {
					// Handle error response here
					console.error(
						"Error occurred while sending selected value to the controller."
					);
				},
			});
		});
	});
});


// $(document).ready(function () {
//     $("#Course_name").on("change", function () {
//         // Retrieve values from various input fields
//         var InstutionName = $("#InstutionName").val();
//         var course_name = $("#Course_name").val();
//         var coursetype = $("#Course_type").val();
//         var department_name = $("#DepartmentName").val();
//         var batch = $("#Batch").val();

//         // AJAX request setup
//         $.ajax({
//             type: "POST",
//             url: baseurl + "Semester_Attendance/get_semesters",  // Assuming 'baseurl' is defined elsewhere
//             data: {
//                 batch: batch,
//                 InstutionName: InstutionName,
//                 Course_name: course_name,
//                 Department_name: department_name,
//                 Course_type: coursetype,
//             },
//             success: function (response) {
//                 var responseData = JSON.parse(response);
//                 var sem = { "": "" };  // Initial dropdown options

//                 // Loop through the response data and populate dropdown options
//                 for (var i = 0; i < responseData.length; i++) {
// 					var DName = responseData[i];
// 					sem[DName.Semester] = DName.Semester;
// 				}

// 				// alert(DName)

//                 // Update the Semester dropdown with new options
//                 $("#Semesters").empty();  // Clear existing options
//                 $.each(sem, function (key, value) {
//                     $("#Semesters").append(
//                         $("<option></option>").attr("value", key).text(value)
//                     );
//                 });

// 				$("#Semesters option:eq(1)").prop("selected", true);
//             },
//             error: function (xhr, status, error) {
//                 // Handle error response here
//                 console.error("Error occurred while sending selected value to the controller.");
//             },
//         });
//     });
// });

$(document).ready(function () {
	$("#InstutionName").on("change", function () {
		var InstutionName = $("#InstutionName").val();
		$("#Course_type").on("change", function () {
			var Course_type = $("#Course_type").val();
			$.ajax({
				type: "POST",
				url: baseurl + "Student_Attendance/get_department",
				data: { InstutionName: InstutionName, Course_type: Course_type },

				success: function (response) {
					var responseData = JSON.parse(response);
					var dropdownOptions = { "": "Select Department" }; // Initial dropdown options
					
					// Loop through the response data and add each district to the dropdown options
					for (var i = 0; i < responseData.length; i++) {
						var DName = responseData[i];
						dropdownOptions[DName.DepartmentName] = DName.DepartmentName;
						
					}
					// Update the dropdown with the new options
					$("#DepartmentName").empty(); // Clear existing options
					$.each(dropdownOptions, function (key, value) {
						$("#DepartmentName").append(
							$("<option></option>").attr("value", key).text(value)
						);
					});
					
				},
				error: function (xhr, status, error) {
					// Handle error response here
					console.error(
						"Error occurred while sending selected value to the controller."
					);
				},
			});
		});
	});
});


$(document).ready(function () {
	$("#InstutionName").on("change", function () {
		var InstutionName = $("#InstutionName").val();
		$("#Course_type").on("change", function () {
			var Course_type = $("#Course_type").val();
			$("#DepartmentName").on("change", function () {
				var DepartmentName = $("#DepartmentName").val();
			$.ajax({
				type: "POST",
				url: baseurl + "Student_Attendance/get_course",
				data: { InstutionName: InstutionName, Course_type: Course_type , DepartmentName : DepartmentName },

				success: function (response) {
					var responseData = JSON.parse(response);
					var Course = { "": "Select Course" }; // Initial dropdown options
					var Section = { "": "Select Section" }; // Initial dropdown options
					
					// Loop through the response data and add each district to the dropdown options
					for (var i = 0; i < responseData.length; i++) {
						var DName = responseData[i];
						Course[DName.CourseName] = DName.CourseName;
						Section[DName.Section] = DName.Section;
						
					}
					// Update the dropdown with the new options
					$("#Course_name").empty(); // Clear existing options
					$.each(Course, function (key, value) {
						$("#Course_name").append(
							$("<option></option>").attr("value", key).text(value)
						);
					});

					// Update the dropdown with the new options
					$("#Section").empty(); // Clear existing options
					$.each(Section, function (key, value) {
						$("#Section").append(
							$("<option></option>").attr("value", key).text(value)
						);
					});
					
				},
				error: function (xhr, status, error) {
					// Handle error response here
					console.error(
						"Error occurred while sending selected value to the controller."
					);
				},
			});
		});
	});
});
});




$(document).ready(function () {
	// Get today's date
	var today = new Date().toISOString().split("T")[0];

	// Calculate yesterday's date
	var yesterday = new Date();
	yesterday.setDate(yesterday.getDate() - 5);
	var yesterdayFormatted = yesterday.toISOString().split("T")[0];

	// Set the max and min attributes of the date input
	$("#date").attr("max", today);
	$("#date").attr("min", yesterdayFormatted);
});

$(document).ready(function () {
	$("#attendance-sheet").hide(); // Initially hide attendance sheet

	// Event listener for fetching student list
	$("#get-list").on("click", function () {
		var InstitutionName = $("#InstutionName").val();
		var CourseType = $("#Course_type").val();
		var DepartmentName = $("#DepartmentName").val();
		var Batch = $("#Batch").val();
		var CourseName = $("#Course_name").val();
		var Semester = $("#Semester").val();
		var Section = $("#Section").val();
		var date = $("#date").val(); // Get selected year (e.g., 2023)

		// Example headers (replace with your actual headers)
		var headers = {
			Authorization: "Bearer YourAccessToken",
			"Custom-Header": "CustomValue",
		};

		$.ajax({
			type: "POST",
			url: baseurl + "Student_Attendance/get_student",
			headers: headers,
			data: {
				InstitutionName: InstitutionName,
				CourseType: CourseType,
				DepartmentName: DepartmentName,
				Batch: Batch,
				CourseName: CourseName,
				Semester : Semester,
				Section: Section,
				date: date,
			},
			success: function (response) {
				var responseData = JSON.parse(response);

				// Clear existing table headers and rows
				$("#sheet tbody").empty();

				// If responseData is not empty and has at least one student object
				if (responseData.length > 0) {
					// Append data rows to table
					$.each(responseData, function (index, student) {
						var row =
							"<tr>" +
							"<td><input type='checkbox' class='check-item'></td>" + // Checkbox column
							"<td>" +
							(index + 1) +
							"</td>" +
							"<td>" +
							student.Student_Id +
							"</td>" +
							"<td>" +
							student.Exam_Reg_No +
							"</td>" +
							"<td>" +
							student.Semester_1 +
							"</td>" +
							"<td>" +
							student.name +
							"</td>";

						// Add hour columns
						for (var i = 1; i <= 6; i++) {
							var attendanceValue = student["hour" + i] || ""; // Default to empty string if value is undefined

							row += "<td>" +
    "<select class='form-control form-control hour-dropdown' style='width: 50px;' data-index='" +
    index +
    "' data-hour='" +
    i +
    "'>" +
    "<option value='NA' " +
    (attendanceValue === "NA" ? "selected" : "") +
    ">NA</option>" +
    "<option value='1' " +
    (attendanceValue === "1" ? "selected" : "") +
    ">P</option>" +
    "<option value='0' " +
    (attendanceValue === "0" ? "selected" : "") +
    ">A</option>" +
    "<option value='-1' " +
    (attendanceValue === "-1" ? "selected" : "") +
    ">L</option>" +
    "<option value='-2' " +
    (attendanceValue === "-2" ? "selected" : "") +
    ">PA</option>" +
    "<option value='-3' " +
    (attendanceValue === "-3" ? "selected" : "") +
    ">OD</option>" +
    "</select></td>";
						}

						// Add action column with delete button
						row +=
							"<td><button class='btn btn-danger btn-sm delete-btn' data-id='" +
							student.id +
							"'><i class='fas fa-trash' style='color: inherit; background-color: transparent;'></i></button></td>" +
							"</tr>";
						$("#sheet tbody").append(row);
					});

					$("#attendance-sheet").show(); // Show attendance sheet
				} else {
					console.log("No data returned from the server.");
				}
			},
			error: function (xhr, status, error) {
				console.error("Error occurred while fetching student attendance data.");
			},
		});
	});

	// Event listener for "Update Record" button click
	$("#Update_record").on("click", function () {
		var updateRows = []; // Array to store data for rows to be updated

		// Loop through all checkboxes to find checked ones
		$(".check-item:checked").each(function () {
			var row = $(this).closest("tr"); // Get the parent row
			var studentId = row.find("td:eq(2)").text(); // Assuming Student_Id is in the third column
			var Exam_reg = row.find("td:eq(3)").text();
			var semester = row.find("td:eq(4)").text();
			var name = row.find("td:eq(5)").text();

			// Array to store attendance values for each hour
			var attendanceValues = [];
			row.find(".hour-dropdown").each(function () {
				attendanceValues.push($(this).val());
			});

			var rowData = {
				StudentId: studentId,
				Exam_reg: Exam_reg,
				semester: semester,
				name: name,
				InstitutionName: $("#InstutionName").val(), // Retrieve InstitutionName from the form
				CourseType: $("#Course_type").val(), // Retrieve CourseType from the form
				DepartmentName: $("#DepartmentName").val(), // Retrieve DepartmentName from the form
				Batch: $("#Batch").val(), // Retrieve Batch from the form
				CourseName: $("#Course_name").val(), // Retrieve CourseName from the form
				Section: $("#Section").val(), // Retrieve Section from the form
				date: $("#date").val(), // Retrieve year from the form
				AttendanceValues: attendanceValues, // Array of attendance values for each hour
			};

			updateRows.push(rowData);
		});

		// Example AJAX call with headers to update records
		var headers = {
			Authorization: "Bearer YourAccessToken",
			"Custom-Header": "CustomValue",
		};

		$.ajax({
			type: "POST",
			url: baseurl + "Student_Attendance/Update",
			headers: headers,
			data: {
				rows: updateRows,
			},
			success: function (response) {
				var responseData = JSON.parse(response);

				if (responseData == 1) {
					swal({
						title: "Good job!",
						text: "Student attendance has been updated.",
						icon: "success",
						button: "OK",
					}).then(function () {
						window.location.href = baseurl + "Student_Attendance";

						// Set timer for 5 seconds (5000 milliseconds)
						setTimeout(function () {
							// Additional code to run after 5 seconds, if needed
							console.log("Timer finished");
						}, 5000); // Adjust the time as needed (5000 milliseconds = 5 seconds)
					});
				}
			},
			error: function (xhr, status, error) {
				console.error("Error occurred while updating records");
				// Optionally, handle errors or show user-friendly error messages
			},
		});
	});

	// Event listener for delete button (dynamic binding)
	$("#sheet").on("click", ".delete-btn", function () {
		var studentId = $(this).data("id");
		// Perform delete operation or any other action here
		console.log("Delete button clicked for student ID:", studentId);
	});

	// Event listener for checkbox (dynamic binding)
	$("#sheet").on("change", ".check-item", function () {
		var clickedrows = []; // Array to store selected rows

		// Loop through all checkboxes to find checked ones
		$(".check-item").each(function () {
			if ($(this).prop("checked")) {
				var row = $(this).closest("tr"); // Get the parent row
				var studentId = row.find("td:eq(2)").text(); // Assuming Student_Id is in the third column

				// Example of what you can do with the checked row
				console.log("Selected Student ID:", studentId);

				// Push the selected row data or ID into the array
				clickedrows.push(studentId);
			}
		});

		// Example of how to use clickedrows array
		console.log("Selected rows array:", clickedrows);
	});

	// Event listener for dropdown change (hour-dropdown)
	$("#sheet").on("change", ".hour-dropdown", function () {
		var dataIndex = $(this).data("index");
		var dataHour = $(this).data("hour");
		var selectedValue = $(this).val();

		// Update updateRows with new dropdown values
		updateRows.forEach(function (rowData) {
			if (rowData.StudentId === dataIndex) {
				rowData.AttendanceValues[dataHour - 1] = selectedValue; // Adjust dataHour index to match array (1-based to 0-based)
			}
		});

		console.log(
			"Dropdown changed - Data Index:",
			dataIndex,
			"Data Hour:",
			dataHour,
			"Selected Value:",
			selectedValue
		);
	});

	// Select All checkbox functionality
	$("#Selected").on("click", function () {
		// alert("Coming...1");
		$(".check-item").each(function () {
			$(this).prop("checked", !$(this).prop("checked"));
		});
	});
});




$(document).ready(function () {

	
	$('#table-view').hide();
	$('#status-view').hide();

    $("#get_aten_list").on("click", function () {
        var InstitutionName = $("#InstutionName").val();
        var CourseType = $("#Course_type").val();
        var DepartmentName = $("#DepartmentName").val();
        var Batch = $("#Batch").val();
        var CourseName = $("#Course_name").val();
		var Semester = $("#Semester").val();
        var Section = $("#Section").val();
        var date_1 = $("#date_1").val();

        $.ajax({
            type: "POST",
            url: baseurl + "Student_Attendance/get_atten_student",
            data: {
                InstitutionName: InstitutionName,
                CourseType: CourseType,
                DepartmentName: DepartmentName,
                Batch: Batch,
                CourseName: CourseName,
				Semester : Semester,
                Section: Section,
                date_1: date_1,
            },

			
            success: function (response) {
                try {
                    var responseData = JSON.parse(response);

					var present = responseData.get_present;
					var absent = responseData.get_absent;
					var permission = responseData.get_permission;
					var od= responseData.get_od;

					$('#present').text(present);
					$('#absent').text(absent);
					$('#permission').text(permission);
					$('#od').text(od);

                    $('#Atten_stud').empty(); // Clear existing table rows

                    $.each(responseData.get_atten_students, function(index, item) {

						$('#table-view').show();
						$('#status-view').show();
						
                        var row = `<tr>
                            <td>${index + 1}</td>
                            <td>${item.StudentId}</td>
                            <td>${item.Exam_Registration_No}</td>
                            <td>${item.Semester}</td>
                            <td>${escapeHtml(item.StudentName)}</td>`;

                        
                        // Loop through days (1 to 31)
                        for (let day = 1; day <= 31; day++) {
                            let dayKey = `DAY_${day}`;
                            let dayValue = item[dayKey] !== undefined ? item[dayKey] : '';
                            row += `<td>${escapeHtml(dayValue)}</td>`;
                        }

                        row += `<td>${item.Total_Present}</td>
                            <td>${item.Total_Absent}</td>
                            <td>${item.Percentage}</td>
                            <td>${item.CreatedBy}</td>`;

                        row += `</tr>`;
                        
                        $('#Atten_stud').append(row);
                    });
                } catch (error) {
                    console.error("Error parsing response:", error);
                }
            },
            error: function (xhr, status, error) {
                console.error("AJAX request failed:", status, error);
                // Optionally handle error display to the user
            }
        });
    });

    // Function to escape HTML characters
    function escapeHtml(unsafe) {
        return typeof unsafe === 'string'
            ? unsafe.replace(/[&<"']/g, function(m) {
                switch (m) {
                    case '&':
                        return '&amp;';
                    case '<':
                        return '&lt;';
                    case '"':
                        return '&quot;';
                    case "'":
                        return '&#39;';
                    default:
                        return m;
                }
            })
            : unsafe;
    }
});



$(document).ready(function (){

	$("#absent_reports").hide();      

	$("#absentees_report").on("click", function () {

		var InstitutionName = $("#InstutionName").val();
		var CourseType = $("#Course_type").val();
		var DepartmentName = $("#DepartmentName").val();
		var Date = $("#Date").val();

		


		$.ajax({
			type: "POST",
			url: baseurl + "Student_Attendance/get_absentees",
			
			data: {
				InstitutionName: InstitutionName,
				CourseType : CourseType,
				DepartmentName : DepartmentName,
				Date : Date
			},

			success: function (response) {
				var responseData = JSON.parse(response);
				$('#student_absentees tbody').empty();

				$("#absent_reports").show();   

				$.each(responseData, function(index, item) {
					var row = `<tr>
						<td><input type="checkbox" class="check-item"></td>
						<td>${index + 1}</td>
						<td>${item.Exam_reg}</td>
						<td>${item.StudentName}</td>    
						<td>${item.Gender}</td>
						<td>${item.Mobile}</td>
						<td>${item.CourseName}</td>
						<td>${item.Semester}</td>
						<td>${item.AttendanceStatus}</td>
						<td><button class="send-message-btn btn btn-outline-info btn-sm">Send Message</button></td>
					</tr>`;
					
					$('#student_absentees tbody').append(row);
				});
				
				// Toggle all checkboxes when "Selected_all" button is clicked
				$("#selected_all").on("click", function () {
					$(".check-item").each(function () {
						$(this).prop("checked", !$(this).prop("checked"));
					});
				});

				
				$("#update_message").on("click", function () {
					
					var selectedItems = [];
				
					
					$(".check-item:checked").each(function () {
						// Find the parent row (tr) to get all data within that row
						var row = $(this).closest("tr");
						var item = {
							// Extract data from each column within the row
							index: row.find("td:eq(1)").text().trim(), 
							exam_reg: row.find("td:eq(2)").text().trim(),
							student_name: row.find("td:eq(3)").text().trim(),
							gender: row.find("td:eq(4)").text().trim(),
							mobile: row.find("td:eq(5)").text().trim(),
							course_name: row.find("td:eq(6)").text().trim(),
							semester: row.find("td:eq(7)").text().trim(),
							attendance_status: row.find("td:eq(8)").text().trim(),
							Date : Date,
							InstitutionName : InstitutionName,
							DepartmentName : DepartmentName
							
						};
						selectedItems.push(item);
						
					});
				
					
					console.log(selectedItems); 
				
				
					$.ajax({
						type: "POST",
						url: baseurl+"Mail/inform",
						data: JSON.stringify(selectedItems),
						contentType: "application/json",
						success: function (response) {

							var responseData = JSON.parse(response);
							
							if (responseData == 'SAVE') {
								swal({
									title: "Good job!",
									text: "Student attendance has been updated.",
									icon: "success",
									button: "OK",
								}).then(function () {
									window.location.href = baseurl + "Sms";
			
									// Set timer for 5 seconds (5000 milliseconds)
									setTimeout(function () {
										// Additional code to run after 5 seconds, if needed
										console.log("Timer finished");
									}, 5000); // Adjust the time as needed (5000 milliseconds = 5 seconds)
								});
							}
							
						},
						error: function (xhr, status, error) {
						
							console.error("Error:", error);
						}
					});
				
					
					return false;
				});
				
			},
			error: function (xhr, status, error) {
				console.error("Error occurred while updating records");
				// Optionally, handle errors or show user-friendly error messages
			},
		});
	
	
	})
	

})



