$(document).ready(function() {
    var departmentName = $("#Department_name001").val();

    function fetchCourseTypes(departmentName) {
        $.ajax({
            type: "POST",
            url: baseurl + "Student_Timetable/Course_type",
            data: { department_name: departmentName },
            dataType: "json",
            success: function(response) {
                var dropdownOptions = { "": "Select Course Type" };

                $.each(response, function(index, item) {
                    dropdownOptions[item.Course_type] = item.Course_type;
                });

                $('#Course_type22').empty();
                $.each(dropdownOptions, function(key, value) {
                    $('#Course_type22').append($('<option></option>').attr('value', key).text(value));
                });

                // Fetch batches for the default selected course type
                var defaultCourseType = $('#Course_type22').val();
                fetchBatches(defaultCourseType, departmentName);
            },
            error: function(xhr, status, error) {
                console.error('Error occurred while fetching course types.');
            }
        });
    }

    function fetchBatches(courseType, departmentName) {
        $.ajax({
            type: "POST",
            url: baseurl + "Student_Timetable/get_section1",
            data: { courseType: courseType, department_name: departmentName },
            success: function(response) {
                var responseData = JSON.parse(response);
                var batchOptions = { "": "Select Batch" };

                $.each(responseData, function(index, Batch) {
                    batchOptions[Batch.Batch] = Batch.Batch;
                });

                $("#Batch2").empty();
                $.each(batchOptions, function(key, value) {
                    $("#Batch2").append($('<option></option>').attr('value', key).text(value));
                });

                // Fetch sections for the default selected batch
                var defaultBatch = $('#Batch2').val();
                fetchSectionsForBatch(courseType, departmentName, defaultBatch);
            },
            error: function(xhr, status, error) {
                console.error('Error occurred while fetching batches.');
            }
        });
    }

    function fetchSectionsForBatch(courseType, departmentName, Batch) {
        $.ajax({
            type: "POST",
            url: baseurl + "Student_Timetable/Section23",
            data: { courseType: courseType, department_name: departmentName, Batch: Batch },
            success: function(response) {
                var responseData = JSON.parse(response);
                var sectionOptions = { "": "Select Section" };

                $.each(responseData, function(index, section) {
                    sectionOptions[section.Class_Section] = section.Class_Section;
                });

                $("#Section23").empty();
                $.each(sectionOptions, function(key, value) {
                    $("#Section23").append($('<option></option>').attr('value', key).text(value));
                });

                var defaultSection = $('#Section23').val();
                fetchTimetable(departmentName, courseType, defaultSection, Batch);
            },
            error: function(xhr, status, error) {
                console.error('Error occurred while fetching sections.');
            }
        });
    }

    function fetchTimetable(departmentName, courseType, section, Batch) {
        $.ajax({
            type: "POST",
            url: baseurl + "Student_Timetable/get_timetable",
            data: { department_name: departmentName, courseType: courseType, section: section, Batch: Batch },
            dataType: "json",
            success: function(response) {
                // Clear existing timetable data
                $('#timetableTable1 tbody').find('td:not(:first-child)').empty();
                
                // Populate timetable data
                $.each(response, function(index, item) {
                    var dayIndex = item.Dayss.replace('Day ', '');
                    var hours = item.Hours;
                    
                    $('#timetableTable1 tbody tr[data-day="' + dayIndex + '"]').find('td').each(function(hourIndex) {
                        if (hourIndex > 0) { // Skip the first column (Day column)
                            var hourKey = 'Hour_' + hourIndex;
                            $(this).html(hours[hourKey]);
                        }
                    });
                });
            },
            error: function(xhr, status, error) {
                console.error('Error occurred while fetching timetable data.');
            }
        });
    }

    if (departmentName) {
        fetchCourseTypes(departmentName);
    }

    $("#Department_name001").change(function() {
        departmentName = $(this).val();
        fetchCourseTypes(departmentName);
    });

    $("#Course_type22").change(function() {
        var selectedCourseType = $(this).val();
        fetchBatches(selectedCourseType, departmentName);
    });

    $("#Batch2").change(function() {
        var selectedCourseType = $('#Course_type22').val();
        var selectedBatch = $(this).val();
        fetchSectionsForBatch(selectedCourseType, departmentName, selectedBatch);
    });

    $("#Section23").change(function() {
        var selectedCourseType = $('#Course_type22').val();
        var selectedBatch = $('#Batch2').val();
        var selectedSection = $(this).val();
        fetchTimetable(departmentName, selectedCourseType, selectedSection, selectedBatch);
    });
});
     