$(document).ready(function () {
	$("#InstutionName").on("change", function () {
		var InstutionName = $("#InstutionName").val();
		$("#Course_type").on("change", function () {
			var Course_type = $("#Course_type").val();
			$("#DepartmentName").on("change", function () {
				var DepartmentName = $("#DepartmentName").val();
				$("#Course_name").on("change", function () {
					var Course_name = $("#Course_name").val();

					$.ajax({
						type: "POST",
						url: baseurl + "Management/FeesType",
						data: {
							InstutionName: InstutionName,
							Course_type: Course_type,
							DepartmentName: DepartmentName,
							Course_name: Course_name,
						},
						success: function (response) {
							var responseData = JSON.parse(response);

							var FeesType = { "": "Select Fees Type" }; // Initial dropdown options

							for (var i = 0; i < responseData.length; i++) {
								var DName = responseData[i];
								FeesType[DName.FeesType] = DName.FeesType;
							}
							// Update the dropdown with the new options
							$("#FeesTypes").empty(); // Clear existing options
							$.each(FeesType, function (key, value) {
								$("#FeesTypes").append(
									$("<option></option>").attr("value", key).text(value)
								);
							});
						},
						error: function (xhr, status, error) {
							// Handle error response here
							console.error(
								"Error occurred while sending selected value to the controller."
							);
						},
					});
				});
			});
		});
	});
});

// $(document).ready(function () {
// 	$("#Fees").on("keyup", function () {
// 		var amount = $(this).val().replace(/\D/g, "");
// 		$(this).val(formatAmount(amount));
// 	});

// 	function formatAmount(amount) {
// 		return amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
// 	}
// });

// $(document).ready(function () {
// 	$("#Concession").on("keyup", function () {
// 		var amount = $(this).val().replace(/\D/g, "");
// 		$(this).val(formatAmount(amount));
// 	});

// 	function formatAmount(amount) {
// 		return amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
// 	}
// });

$(document).ready(function () {
	$("#Update_fees").on("click", function () {
		var InstutionName = $("#InstutionName").val();
		var Course_type = $("#Course_type").val();
		var Department_attendance = $("#DepartmentName").val();
		var Course_name = $("#Course_name").val();
		var Batch = $("#Batch").val();
		var Semester = $("#Semesters").val();
		var FeesType = $("#FeesTypes").val();
		var Fees = $("#Fees").val();

		$.ajax({
			type: "POST",
			url: baseurl + "Management/update_fees",
			data: {
				InstutionName: InstutionName,
				Course_type: Course_type,
				Department_attendance: Department_attendance,
				Course_name: Course_name,
				Batch: Batch,
				Semester: Semester,
				FeesType: FeesType,
				Fees: Fees,
			},
			success: function (response) {
				var responseData = JSON.parse(response);

				if (responseData == 1) {
					Swal.fire({
						icon: "success",
						title: "Success!",
						text: "Your changes to the fee assignment have been successfully updated and saved..",
						confirmButtonText: "OK",
					}).then(() => {
						location.reload(); // Reload the page immediately after clicking OK
					});
				} else if (responseData == "true") {
					Swal.fire({
						icon: "error", // Note: Use lowercase 'error' instead of 'Error'
						title: "Oops!",
						text: "The changes to the fee assignment have already been successfully updated and saved.",
						confirmButtonText: "OK",
					}).then(() => {
						location.reload(); // Reload the page immediately after clicking OK
					});
				}
			},
			error: function (xhr, status, error) {
				console.error(
					"Error occurred while sending selected value to the controller."
				);
			},
		});
	});
});
$(document).ready(function () {
	// Function to fetch student data based on selected criteria
	function fetchStudentData() {
		var InstutionName = $("#InstutionName").val();
		var Course_type = $("#Course_type").val();
		var DepartmentName = $("#DepartmentName").val();
		var Course_name = $("#Course_name").val();
		var Batch = $("#Batch").val();
		var Semester = $("#Semesters").val();
		var Section = $("#Section").val();

		$.ajax({
			type: "POST",
			url: baseurl + "Management/get_student",
			data: {
				InstutionName: InstutionName,
				Course_type: Course_type,
				DepartmentName: DepartmentName,
				Course_name: Course_name,
				Batch: Batch,
				Semester: Semester,
				Section: Section,
			},
			success: function (response) {
				var responseData = JSON.parse(response);

				var Student_id = { "": "Select Student Id" }; // Initial dropdown options

				for (var i = 0; i < responseData.length; i++) {
					var student = responseData[i];
					Student_id[student.Student_Id] = student.Student_Id;
				}

				// Update the dropdown with the new options
				$("#Student_id").empty(); // Clear existing options
				$.each(Student_id, function (key, value) {
					$("#Student_id").append(
						$("<option></option>").attr("value", key).text(value)
					);
				});
			},
			error: function (xhr, status, error) {
				// Handle error response here
				console.error("Error occurred while fetching student data.");
			},
		});
	}

	// Fetch student data initially when the document is ready
	fetchStudentData();

	// Event listeners for each dropdown
	$(
		"#InstutionName, #Course_type, #DepartmentName, #Course_name, #Batch, #Semesters, #Section"
	).on("change", function () {
		fetchStudentData();
	});
});

$(document).ready(function () {
	$("#Student_id").on("change", function () {
		var Student_id = $("#Student_id").val();

		$.ajax({
			type: "POST",
			url: baseurl + "Management/student_name",
			data: {
				Student_id: Student_id,
			},
			success: function (response) {
				var responseData = JSON.parse(response);

				var studentNames = "";

				for (var i = 0; i < responseData.length; i++) {
					var student = responseData[i];
					studentNames += student.name + ", "; // Append each student name
				}

				// Remove the trailing ", " from the end of the string
				studentNames = studentNames.slice(0, -2);

				// Update the input text box with student names
				$("#StudentName").val(studentNames);
			},
			error: function (xhr, status, error) {
				// Handle error response here
				console.error(
					"Error occurred while sending selected value to the controller."
				);
			},
		});
	});
});

$(document).ready(function () {
	$("#consession_fees").on("click", function () {
		var InstutionName = $("#InstutionName").val();
		var Course_type = $("#Course_type").val();
		var DepartmentName = $("#DepartmentName").val();
		var Course_name = $("#Course_name").val();
		var Batch = $("#Batch").val();
		var Semesters = $("#Semesters").val();
		var Section = $("#Section").val();
		var Student_id = $("#Student_id").val();
		var StudentName = $("#StudentName").val();
		var FeesType = $("#FeesTypes").val();
		var Concession = $("#Concession").val();

		$.ajax({
			type: "POST",
			url: baseurl + "Management/concession_fees",
			data: {
				InstutionName: InstutionName,
				Course_type: Course_type,
				DepartmentName: DepartmentName,
				Course_name: Course_name,
				Batch: Batch,
				Semesters: Semesters,
				Section: Section,
				Student_id: Student_id,
				StudentName: StudentName,
				FeesType: FeesType,
				Concession: Concession,
			},
			success: function (response) {
				var responseData = JSON.parse(response);

				if (responseData == 1) {
					Swal.fire({
						icon: "success",
						title: "Success!",
						text: "Concession fees has been successfully updated and saved..",
						confirmButtonText: "OK",
					}).then(() => {
						location.reload(); // Reload the page immediately after clicking OK
					});
				} else if (responseData == "true") {
					Swal.fire({
						icon: "success",
						title: "Success!",
						text: "Concession fees Already has been updated for this student.",
						confirmButtonText: "OK",
					}).then(() => {
						location.reload(); // Reload the page immediately after clicking OK
					});
				}
			},
			error: function (xhr, status, error) {
				console.log(xhr.responseText);
				Swal.fire({
					icon: "error",
					title: "Oops...",
					text: "An error occurred while updating concession fees. Please try again later.",
					confirmButtonText: "OK",
				});
			},
		});
	});
});
$(document).ready(function () {
    $("#razorpay-dfghjk").on("click", function () {
       
        $(this).prop('disabled', true);

        

        $.ajax({
            type: "POST",
            url: baseurl + "Management/calculate",
            dataType: 'json',
            success: function (response) {
                var order_id = response.order_id; // Correct variable name
                var amount = response.amount; // Correct variable name
                var Email = response.Email; // Correct variable name
                var Phone = response.Mobile; // Correct variable name
                var Name = response.name;

                process(order_id, amount, Email,Phone,Name); // Correct function call
            },
            error: function (xhr, status, error) {
                // Handle error
                console.error(error);
                // Re-enable the button on error if needed
                $("#razorpay").prop('disabled', false);
            },
        });
    });
});

function process(order_id, amount, Email,Phone,Name) {

   
    var amount_1 = amount * 1000;
    var rp = "rzp_test_ERi8OTWrDXP06W";
    var options = {
        "key": rp,
        "amount": amount,
        "currency": "INR",
        "name": "Annaiveilankannis Group Of Educational Institute",
        "description": "Test Transaction",
        "order_id": order_id,
        "handler": function (response) {
            // alert(response.razorpay_payment_id);
            // alert(response.razorpay_order_id);
            // alert(response.razorpay_signature);
            document.getElementById('payment_id').value = response.razorpay_payment_id;
            document.getElementById('order_id').value = response.razorpay_order_id;
            document.getElementById('signature_value').value = response.razorpay_signature;
            document.getElementById('razorpay-form').submit();
        },
        "prefill": {
            "name":Name ,
            "email":Email ,
            "contact": Phone
        },
        "notes": {},
        "theme": {
            "color": "#3399cc"
        }
    };

    var rzp1 = new Razorpay(options);
    rzp1.open();
}



$(document).ready(function () {

    $.ajax({
        type: "POST",
        url: baseurl + "Management/get_feestype",
        dataType: 'json',
        success: function (responseData) {

            // Check the structure of responseData with console.log
            console.log(responseData);

            var feestype = { "": "Select FeesType" }; // Initial dropdown options

            // Loop through the response data and add each FeesType to the dropdown options
            $.each(responseData, function (index, item) {
                feestype[item.FeesType] = item.FeesType;
            });

            // Update the dropdown with the new options
            $("#FeesType").empty(); // Clear existing options
            $.each(feestype, function (key, value) {
                $("#FeesType").append(
                    $("<option></option>").attr("value", key).text(value)
                );
            });

        },
        error: function (xhr, status, error) {
            // Handle error
            console.error(error);
            // Re-enable the button on error if needed
            $("#razorpay").prop('disabled', false);
        },
    });

});

$(document).ready(function () {

    $("#FeesType").on("change",function(){
        var FeesType = $("#FeesType").val();

        $.ajax({
            type: "POST",
            url: baseurl + "Management/fee",
            data: {
                FeesType: FeesType
            },
            dataType: 'json',
            success: function (responseData) {
                
            },
            error: function (xhr, status, error) {
                // Handle error
                console.error(error);
            },
        });
    })

})

$(document).ready(function () {

	$("#Check_Fees").on("click", function () {

		var InstutionName = $("#InstutionName").val();
		var StudentAdmisssionNo = $("#StudentAdmisssionNo").val();

		$.ajax({
			type: "POST",
            url: baseurl + "Management/check_fees",
            data: {
                InstutionName: InstutionName,
                StudentAdmisssionNo: StudentAdmisssionNo,
            },
            dataType: 'json',
            success: function (responseData) {

				var student_details = responseData.check_fees;
				var Name = student_details['name'];
				var RollNo =  student_details['RollNo'];
				var DOB = student_details['dob'];
				var Batch =  student_details['Batch_1'];
				var Course = student_details['CourseName_1'];
				var Semester =  student_details['Semester_1'];
				var Exam_Reg_No = student_details['Exam_Reg_No'];

				$("#StudentName").text(Name);
				$("#RollNo").text(RollNo);
				$("#DOB").text(DOB);
				$("#Batch").text(Batch);
				$("#Course").text(Course);
				$("#Semester").text(Semester);
				$("#Exam_Reg_No").text(Exam_Reg_No);


				var Fees_Details = responseData.fees_details;

				$('#fees_append').empty();

				// Assuming Fees_Details is your array of data objects
				Fees_Details.forEach((item, index) => {
					var s_no = index + 1;
					var amount = item.Fees;
					var semester = item.Semester;
					var feestype = item.FeesType;
					var PaymentStatus = item.PaymentStatus;
				
					// Determine background color based on PaymentStatus
					var rowClass;
					if (PaymentStatus === 'Paid') {
						rowClass = 'table-success'; // Bootstrap 5 class for success background
					} else if (PaymentStatus === 'Pending') {
						rowClass = 'table-warning'; // Bootstrap 5 class for warning background
					} else {
						rowClass = ''; // Default to no specific background
					}
				
					// Construct the row with conditional background color
					var row = "<tr class='" + rowClass + "'>";
					row += "<td>" + s_no + "</td>";
					row += "<td>" + semester + "</td>";
					row += "<td>" + feestype + "</td>";
					row += "<td>" + amount + "</td>";
					row += "<td>"; // Placeholder for status badge (if needed)
					row += "<span class='badge bg-info'>" + PaymentStatus + "</span>"; // Show PaymentStatus as badge for clarity
					row += "</td>";
				
					// Check if PaymentStatus is 'Pending' to show Pay button
					if (PaymentStatus === 'Pending') {
						row += '<td><button class="btn btn-primary pay-btn btn-sm" id="offline_pay" data-bs-toggle="modal" data-bs-target="#loginModal">Pay Now</button></td>';
					} else {
						row += "<td></td>"; // Empty cell if not 'Pending'
					}
				
					row += "</tr>";
				
					// Append the row to the table body with ID 'fees_append'
					$('#fees_append').append(row);
				});
				
            },
            error: function (xhr, status, error) {
                // Handle error
                console.error(error);
            },
        });
            
	})
})


$(document).ready(function() {
    $('#fees_append').on('click', '.pay-btn', function() {
        // Collect data from form fields
        var Instution = $("#InstutionName").val();
        var UserType = $("#usertype").val();
        var Admission = $("#StudentAdmisssionNo").val();
        var PaymentType = "Offline";
        
        // Collect data from button's data attributes
        var s_no = $(this).data('sno');
        var semester = $(this).data('semester');
        var feestype = $(this).data('feetype');
        var amount = $(this).data('amount');
        var status = $(this).data('status');

        // Prepare the data object to send via AJAX
        var rowData = {
            Instution: Instution,
            UserType: UserType,
            Admission: Admission,
            PaymentType: PaymentType,
            s_no: s_no,
            semester: semester,
            feestype: feestype,
            amount: amount,
            status: status
        };

        // Perform AJAX request
        $.ajax({
            url: baseurl + "Management/offline_pay",
            type: 'POST', 
            data: JSON.stringify(rowData), 
            contentType: 'application/json; charset=utf-8', 
            dataType: 'json', 
            success: function(response) {
               
                console.log('Data sent successfully:', response);
                
            },
            error: function(xhr, status, error) {
              
                console.error('Error sending data:', error);
               
            }
        });
    });
});




