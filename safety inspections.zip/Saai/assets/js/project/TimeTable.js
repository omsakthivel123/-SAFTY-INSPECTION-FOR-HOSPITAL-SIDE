
$(document).ready(function () {
	$.ajax({
		type: "POST",
		url: baseurl + "TimeTable/get_institution", // Corrected URL
		success: function (response) {
			var responseData = JSON.parse(response);
			var dropdownOptions = { "": "Select Institution" }; // Initial dropdown options

			// Loop through the response data and add each institution to the dropdown options
			$.each(responseData, function (index, institution) {
				dropdownOptions[institution.InstutionName] = institution.InstutionName;
			});

			// Update the dropdown with the new options
			$("#Institute_name").empty(); // Clear existing options
			$.each(dropdownOptions, function (key, value) {
				$("#Institute_name").append(
					$("<option></option>").attr("value", key).text(value)
				);
			});
		},
		error: function (xhr, status, error) {
			console.error("Error occurred while fetching institutions.");
		},
	});
});

$(document).ready(function () {
	$("#Institute_name").on("change", function () {
		var selectedValue = $(this).val();

		$.ajax({
			type: "POST",
			url: baseurl + "TimeTable/get_departments",
			data: { selectedValue: selectedValue },
			success: function (response) {
				var responseData = JSON.parse(response);
				var dropdownOptions = { "": "Select Department" }; // Initial dropdown options

				// Loop through the response data and add each department to the dropdown options
				$.each(responseData, function (index, department) {
					dropdownOptions[department.DepartmentName] =
						department.DepartmentName;
				});

				// Update the dropdown with the new options
				$("#Department_type1").empty(); // Clear existing options
				$.each(dropdownOptions, function (key, value) {
					$("#Department_type1").append(
						$("<option></option>").attr("value", key).text(value)
					);
				});
			},
			error: function (xhr, status, error) {
				console.error("Error occurred while fetching departments.");
			},
		});
	});
});

// $(document).ready(function(){
//     $('#Department_Name11').on('change', function() {
//         var selectedValue = $(this).val();
//         // alert(selectedValue);
//         $.ajax({
//             type: "POST",
//             url: baseurl+"TimeTable/get_staff",
//             data: {selectedValue : selectedValue},
//             success: function(response) {
//                 var responseData = JSON.parse(response);
//                 // alert(responseData);
//                 var dropdownOptions = {'': 'Select Staff'}; // Initial dropdown options
//                 // Loop through the response data and add each district to the dropdown options
//                 for (var i = 0; i < responseData.length; i++) {
//                     var DName = responseData[i];
//                     dropdownOptions[DName.Name] = DName.Name;
//                 }
//                 // Update the dropdown with the new options
//                 $('#Hod_Name').empty(); // Clear existing options
//                 $.each(dropdownOptions, function(key, value) {
//                     $('#Hod_Name').append($("<option></option>").attr("value", key).text(value));
//                 });
//             },
//             error: function(xhr, status, error) {
//                 // Handle error response here
//                 console.error('Error occurred while sending selected value to the controller.');
//             }
//         });
//     });
//     });

//     $("#Hod_Name").on("change", function () {
//         var selectedValue = $(this).val(); // Get the selected value

//         $.ajax({
//             type: "POST",
//             url: baseurl + "TimeTable/get_staff",
//             data: { selectedValue: selectedValue },
//             dataType: "json",
//             success: function (response) {

//                     var Name = response[0];
//                     var icode = Name.Name;
//                     $('#Staff_Name2').val(icode);

//                 },

//             error: function (xhr, status, error) {
//                 // Handle error response here
//                 console.error('Error occurred while sending selected value to the controller.');
//             }
//         });
//     });

$(document).ready(function () {
	$("#Department_Name11").on("change", function () {
		var selectedValue = $(this).val();
		$.ajax({
			type: "POST",
			url: baseurl + "Department_Wise/get_staff_Id",
			data: { selectedValue: selectedValue },
			success: function (response) {
				var responseData = JSON.parse(response);
				var dropdownOptions = { "": "Select Staff ID" }; // Initial dropdown options
				for (var i = 0; i < responseData.length; i++) {
					var staff = responseData[i];
					dropdownOptions[staff.Staff_id] = staff.Staff_id;
				}
				$("#Staff_ID1").empty(); // Clear existing options
				$.each(dropdownOptions, function (key, value) {
					$("#Staff_ID1").append(
						$("<option></option>").attr("value", key).text(value)
					);
				});
			},
			error: function (xhr, status, error) {
				console.error(
					"Error occurred while sending selected value to the controller."
				);
			},
		});
	});

	$("#Staff_ID1").on("change", function () {
		// alert("b");
		var selectedValue = $(this).val(); // Get the selected value
		$.ajax({
			type: "POST",
			url: baseurl + "Department_Wise/get_staff",
			data: { selectedValue: selectedValue },
			dataType: "json",
			success: function (response) {
				if (response.length > 0) {
					var staff = response[0];
					$("#Staff_Name21").val(staff.Name);
				} else {
					$("#Staff_Name21").val("");
				}
			},
			error: function (xhr, status, error) {
				console.error(
					"Error occurred while sending selected value to the controller."
				);
			},
		});
	});
});

// $(document).ready(function(){
//     $('#Department_type1').on('change', function() {
//         var selectedValue = $(this).val();
//         $.ajax({
//             type: "POST",
//             url:baseurl+"TimeTable/course",
//             data: {selectedValue : selectedValue},
//             success: function(response) {
//                 var responseData = JSON.parse(response);
//                 var dropdownOptions = {'': 'Course Type'}; // Initial dropdown options
//                 // Loop through the response data and add each course type to the dropdown options
//                 for (var i = 0; i < responseData.length; i++) {
//                     var course = responseData[i];
//                     dropdownOptions[course.CourseType] = course.CourseType;
//                 }
//                 // Update the dropdown with the new options
//                 $('#Course_type').empty(); // Clear existing options
//                 $.each(dropdownOptions, function(key, value) {
//                     $('#Course_type').append($("<option></option>").attr("value", key).text(value));
//                 });
//             },
//             error: function(xhr, status, error) {
//                 // Handle error response here
//                 console.error('Error occurred while fetching courses.');
//             }
//         });
//     });
// });

// $(document).ready(function(){
//     $('#Department_type1').on('change', function() {
//         fetchCourses();
//     });

//     $('#Course_type').on('change', function() {
//         fetchCourses();
//     });

//     function fetchCourses() {
//         var department = $('#Department_type1').val();
//         var courseType = $('#Course_type').val();

//         $.ajax({
//             type: "POST",
//             url: baseurl+"TimeTable/course_code",
//             data: {
//                 department: department,
//                 courseType: courseType
//             },
//             success: function(response) {
//                 var responseData = JSON.parse(response);
//                 $('#CourseCode').empty(); // Clear existing options
//                 $('#CourseCode').append($('<option></option>').attr('value', '').text('Select Course Code'));
//                 $.each(responseData, function(index, course) {
//                     $('#CourseCode').append($('<option></option>').attr('value', course.CourseCode).text(course.CourseCode));
//                 });
//             },
//             error: function(xhr, status, error) {
//                 console.error('Error occurred while fetching courses.');
//             }
//         });
//     }

// $('#CourseCode').on('change', function() {
//     var courseCode = $(this).val();
//     $.ajax({
//         type: "POST",
//         url: baseurl + "TimeTable/get_subjects",
//         data: { courseCode: courseCode },
//         success: function(response) {
//             var responseData = JSON.parse(response);
//             var dropdownOptions = { '': 'Subjects' };
//             for (var i = 0; i < responseData.length; i++) {
//                 var subject = responseData[i].Subjects;
//                 dropdownOptions[subject] = subject;
//             }
//             $('#Subjects').empty();
//             $.each(dropdownOptions, function(key, value) {
//                 $('#Subjects').append($("<option></option>").attr("value", key).text(value));
//             });
//         },
//         error: function(xhr, status, error) {
//             console.error('Error occurred while fetching subjects.');
//         }
//     });
// });
// });

// success and Error

$(document).ready(function () {
	$("#wizard-form").submit(function (event) {
		event.preventDefault(); // Prevent default form submission

		// Serialize form data
		var formData = $(this).serialize();

		// AJAX request
		$.ajax({
			type: "POST",
			url: baseurl + "TimeTable/add_Staff2",
			data: formData,
			dataType: "json", // Expect JSON response
			success: function (response) {
				if (response == 1) {
					Swal.fire({
						icon: "success",
						title: "Success!",
						text: "Successfully Assigned The Hod..!.",
						// showCancelButton: true,
						confirmButtonText: "OK",
					}).then((result) => {
						if (result.isConfirmed) {
							window.location.href = baseurl + "TimeTable";
						}
					});
				} else if (response == "true") {
					Swal.fire({
						icon: "error",
						title: "Error!",
						text: "Already This HOD Assigned..!.",
						// showCancelButton: true,
						confirmButtonText: "OK",
					}).then((result) => {
						if (result.isConfirmed) {
							window.location.href = baseurl + "TimeTable";
						}
					});
				}
			},
			error: function (xhr, status, error) {
				// Handle error
				console.error(xhr.responseText);
				// Optionally show error message
			},
		});
	});
});

$(document).ready(function () {
	// Function to fetch and populate department dropdown
	function fetchDepartments() {
		$.ajax({
			type: "POST",
			url: baseurl + "TimeTable/Get_Department",
			success: function (response) {
				var responseData = JSON.parse(response);

				var dropdownOptions = { "": "Select Department" }; // Initial dropdown options

				// Loop through the response data and add each department to the dropdown options
				for (var i = 0; i < responseData.length; i++) {
					var department = responseData[i];
					dropdownOptions[department.Department] = department.Department;
				}

				// Update the dropdown with the new options
				$("#Department").empty(); // Clear existing options
				$.each(dropdownOptions, function (key, value) {
					$("#Department").append(
						$("<option></option>").attr("value", key).text(value)
					);
				});
			},
			error: function (xhr, status, error) {
				// Handle error response here
				console.error("Error occurred while fetching departments.");
			},
		});
	}

	// Function to fetch and populate timetable data based on selected department
	function fetchTimetable(department) {
		$.ajax({
			type: "POST",
			url: baseurl + "TimeTable/getTimetableByDepartment",
			data: { department: department },
			success: function (response) {
				// alert("test");
				var timetableData = JSON.parse(response);
				var tableRows = "";

				// Loop through the timetable data and create table rows
				for (var i = 0; i < timetableData.length; i++) {
					var row = timetableData[i];
					tableRows +=
						"<tr>" +
						"<td>" +
						row.InstitutionName +
						"</td>" +
						"<td>" +
						row.InstitutionCode +
						"</td>" +
						"<td>" +
						row.Department +
						"</td>" +
						"<td>" +
						row.Hod_Name +
						"</td>" +
						// "<td>" + row.CreatedDate + "</td>" +
						// "<td>" + row.ModifiedBy + "</td>" +
						// "<td>" + row.ModifiedOn + "</td>" +
						// "<td>" + row.EnteredBy + "</td>" +
						"</tr>";
				}

				// Update the table body with the new rows
				$("#sheet tbody").html(tableRows);
			},
			error: function (xhr, status, error) {
				// Handle error response here
				console.error("Error occurred while fetching timetable.");
			},
		});
	}

	// Fetch and populate departments on page load
	fetchDepartments();

	// Fetch and populate timetable data when a department is selected
	$("#Department").change(function () {
		var selectedDepartment = $(this).val();
		fetchTimetable(selectedDepartment);
	});
});

$(document).ready(function () {
	$("#hod-view2").hide();
	$("#HOD_details").on("click", function () {
		var InstitutionName = $("#Inst_name_1").val();
		var Inst_codes = $("#Inst_codes").val();
		// var Department_Name = $("#Department_Name11").val();

		$.ajax({
			type: "POST",
			url: baseurl + "TimeTable/get_HOD",
			data: {
				InstitutionName: InstitutionName,
				Inst_codes: Inst_codes,
				// Department_Name: Department_Name,
			},
			success: function (response) {
				try {
					var responseData = JSON.parse(response);

					$("#hod_detail1").empty(); // Clear existing table rows
					$.each(responseData.reports, function (index, item) {
						$("#hod-view2").show();

						var row = `<tr>
                                <td>${index + 1}</td>
                                <td>${escapeHtml(item.InstitutionName)}</td>
                                <td>${escapeHtml(item.InstitutionCode)}</td>
                                <td>${escapeHtml(item.Department)}</td>
                                 <td>${escapeHtml(item.Hod_Name)}</td>
                               
                            </tr>`;

						$("#hod_detail1").append(row);
					});
				} catch (error) {
					console.error("Error parsing response:", error);
				}
			},
			error: function (xhr, status, error) {
				console.error("AJAX request failed:", status, error);
				// Optionally handle error display to the user
			},
		});
	});

	// Function to escape HTML characters
	function escapeHtml(unsafe) {
		return typeof unsafe === "string"
			? unsafe.replace(/[&<"']/g, function (m) {
					switch (m) {
						case "&":
							return "&amp;";
						case "<":
							return "&lt;";
						case '"':
							return "&quot;";
						case "'":
							return "&#39;";
						default:
							return m;
					}
			  })
			: unsafe;
	}
});

$(document).ready(function () {
	// Hide all stages except the first one
	$(".stage").not("#stage1").hide();

	// Function to show next stage
	$(".next").click(function () {
		var currentStage = $(this).closest(".stage");
		currentStage.hide();
		currentStage.next().show();
	});

	// Function to show previous stage
	$(".previous").click(function () {
		var currentStage = $(this).closest(".stage");
		currentStage.hide();
		currentStage.prev().show();
	});

	$(document).ready(function () {
		$("#education-level").change(function () {
			var educationLevel = $(this).val();
			if (educationLevel === "pg") {
				$(".final-info input")
					.prop("disabled", false)
					.prop("required", true)
					.prop("readonly", false);
			} else {
				$(".final-info input")
					.prop("disabled", true)
					.prop("required", false)
					.prop("readonly", true);
			}
		});
	});
});

//edit by subramani 20/07/20-24

$(document).ready(function () {
	var department = $("#Department_name0012").val();

	$.ajax({
		type: "POST",
		url: baseurl + "TimeTable/get_staff_list",
		data: { department: department },
		success: function (response) {
			// alert("test");
			var responseData = JSON.parse(response);

			var dropdownOptions = { "": "Select Staff Id" }; // Initial dropdown options

			// Loop through the response data and add each department to the dropdown options
			for (var i = 0; i < responseData.length; i++) {
				var staff = responseData[i];
				dropdownOptions[staff.Staff_id] = staff.Staff_id;
			}

			// Update the dropdown with the new options
			$("#Staff_id").empty(); // Clear existing options
			$.each(dropdownOptions, function (key, value) {
				$("#Staff_id").append(
					$("<option></option>").attr("value", key).text(value)
				);
			});
		},
		error: function (xhr, status, error) {
			// Handle error response here
			console.error("Error occurred while fetching timetable.");
		},
	});

	$("#Staff_id").on("change", function () {
		var staff_id = $(this).val();
		$.ajax({
			type: "POST",
			url: baseurl + "TimeTable/get_staff_name",
			data: { staff_id: staff_id },
			success: function (response) {
				// alert("test");
				var responseData = JSON.parse(response);
				var staffName = responseData[0].Name;
				$("#Staff_Name").val(staffName);
			},
		});
	});
});

$(document).ready(function () {
	var department = $("#Department_name0012").val();

	$("#Course_type01").on("change", function () {
		var coursetype = $("#Course_type01").val();
		$("#CourseCode01").on("change", function () {
			var coursecode = $("#CourseCode01").val();
			$("#Batch01").on("change", function () {
				var Batch = $("#Batch01").val();

				$.ajax({
					type: "POST",
					url: baseurl + "TimeTable/get_semester",
					data: {
						department: department,
						coursetype: coursetype,
						coursecode: coursecode,
						Batch: Batch,
					},
					success: function (response) {
						// alert("test");
						var responseData = JSON.parse(response);
						var dropdownOptions = { "": "Select Semester" }; // Initial dropdown options

						// Loop through the response data and add each department to the dropdown options
						for (var i = 0; i < responseData.length; i++) {
							var subject = responseData[i];
							dropdownOptions[subject.Semester] = subject.Semester;
						}

						// Update the dropdown with the new options
						$("#Semester").empty(); // Clear existing options
						$.each(dropdownOptions, function (key, value) {
							$("#Semester").append(
								$("<option></option>").attr("value", key).text(value)
							);
						});
					},
				});
			});
		});
	});
});

$(document).ready(function () {
	var department = $("#Department_name0012").val();

	$("#Course_type01").on("change", function () {
		var coursetype = $("#Course_type01").val();
		$("#CourseCode01").on("change", function () {
			var coursecode = $("#CourseCode01").val();
			$("#Batch01").on("change", function () {
				var Batch = $("#Batch01").val();
				$("#Semester").on("change", function () {
					var Semester = $("#Semester").val();

					$.ajax({
						type: "POST",
						url: baseurl + "TimeTable/get_Subjects",
						data: {
							department: department,
							coursetype: coursetype,
							coursecode: coursecode,
							Batch: Batch,
							Semester: Semester,
						},
						success: function (response) {
							var responseData = JSON.parse(response);
							var dropdownOptions = { "": "Select Subject" }; // Initial dropdown options

							// Loop through the response data and add each department to the dropdown options
							for (var i = 0; i < responseData.length; i++) {
								var subject = responseData[i];
								dropdownOptions[subject.SubjectName] = subject.SubjectName;
							}

							// Update the dropdown with the new options
							$("#Subject_Name").empty(); // Clear existing options
							$.each(dropdownOptions, function (key, value) {
								$("#Subject_Name").append(
									$("<option></option>").attr("value", key).text(value)
								);
							});
						},
					});
				});
			});
		});
	});
});

$(document).ready(function () {
	$("#InstutionName").change(function () {
		var InstutionName = $(this).val();

		$.ajax({
			url: baseurl + "TimeTable/get_hod_list",
			type: "POST",
			data: { InstutionName: InstutionName },
			success: function (response) {
				var responseData = JSON.parse(response);

				$("#hod_list").empty(); // Clear existing table rows
				$.each(responseData, function (index, item) {
                    var row = `<tr>
                    <td>${index + 1}</td>
                    <td>${item.InstitutionName}</td>
                    <td>${item.Department}</td>
                    <td>${item.Assigen_Hod_Id}</td>
                    <td>${item.Hod_Name}</td>
                    <td>${item.CreatedBy}</td>
                    <td>${item.ModifiedBy}</td>
                    <td>
                        <a href="#" class="view-icon" data-id="${item.Assigen_Hod_Id}"><i class="fas fa-eye text-primary"></i></a>&nbsp;&nbsp;&nbsp;
                        <a href="#" class="edit-icon" data-id="${item.Assigen_Hod_Id}"><i class="fas fa-edit text-info"></i></a>&nbsp;&nbsp;&nbsp;
                        <a href="#" class="delete-icon" data-id="${item.Assigen_Hod_Id}"><i class="fas fa-trash-alt text-danger"></i></a>
                    </td>
                </tr>`;

               

					$("#hod_list").append(row);
                   
				});
                
			},
		});
	});
});
