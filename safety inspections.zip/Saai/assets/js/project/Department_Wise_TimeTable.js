$(document).ready(function() {
    // Fetch session data and populate hidden inputs
    $.ajax({
        url: baseurl + "Department_Wise/fetchSessionData",
        type: 'GET',
        dataType: 'json',
        success: function(data) {
            if (data && data.InstitutionName) {
                var inst = data.InstitutionName;
                $('#Institution_name').val(inst);

                // $('#Institution_name').val(data.InstitutionName);
            }
            if (data && data.DepartmentName) {
                $('#Department_name').val(data.DepartmentName);
                $('#Department_name').trigger('change'); // Trigger change event to fetch staff names
            }
        },
        error: function(xhr, status, error) {
            console.error('Error fetching session data:', error);
        }
    });



    $('#Department_name').on('change', function() {
        var selectedValue = $(this).val();
        $.ajax({
            type: "POST",
            url: baseurl + "Department_Wise/get_staff_Id",
            data: {selectedValue: selectedValue},
            success: function(response) {
                var responseData = JSON.parse(response);
                // alert(responseData);
                // console.log(responseData);
                var dropdownOptions = {'': 'Select Staff ID'}; // Initial dropdown options
                // Loop through the response data and add each staff name to the dropdown options
                for (var i = 0; i < responseData.length; i++) {
                    var staff = responseData[i];
                    dropdownOptions[staff.Staff_id] = staff.Staff_id;
                }
                // Update the dropdown with the new options
                $('#Staff_ID').empty(); // Clear existing options
                $.each(dropdownOptions, function(key, value) {
                    $('#Staff_ID').append($("<option></option>").attr("value", key).text(value));
                });
            },
            error: function(xhr, status, error) {
                console.error('Error occurred while sending selected value to the controller.');
            }
        });
    });





   
        $("#Staff_ID").on("change", function () {
            var selectedValue = $(this).val(); // Get the selected value
            
            $.ajax({
                type: "POST",
                url: baseurl + "Department_Wise/get_staff",
                data: { selectedValue: selectedValue }, 
                dataType: "json", 
                success: function (response) {
                   
                        var Name = response[0]; 
                        var icode = Name.Name;
                        $('#Staff_Name2').val(icode);
                       
                    }, 
              
                error: function (xhr, status, error) {
                    // Handle error response here
                    console.error('Error occurred while sending selected value to the controller.');
                }
            });
        });

  

$(document).ready(function() {
    $('#Institution_name,#Department_name2, #Course_type,#CourseCode,#Batch1,#Semesters').on('change', function() {
        fetchCourses();
    });

    function fetchCourses() {
        var Institution_name = $('#Institution_name').val();
        var department = $('#Department_name2').val();
        var courseType = $('#Course_type').val();
        var CourseCode = $('#CourseCode').val();
        var Batch = $('#Batch1').val();
        var Semesters = $('#Semesters').val();

        $.ajax({
            type: "POST",
            url: baseurl + "Department_Wise/get_subjects",
            data: {
                Institution_name: Institution_name,
                Department: department,
                courseType: courseType,
                CourseCode: CourseCode,
                Batch: Batch,
                Semesters: Semesters
                
            },
            success: function(response) {
                try {
                    var responseData = JSON.parse(response);
                    var dropdownOptions = { '': 'Select Subject' };
             

                    responseData.forEach(function(subject) {
                        dropdownOptions[subject.SubjectName] = subject.SubjectName;
           
                    });

                    $('#Subjects1').empty();
              

                    $.each(dropdownOptions, function(key, value) {
                        $('#Subjects1').append($("<option></option>").attr("value", key).text(value));
                    });

               
                } catch (e) {
                    console.error('Error parsing response: ' + e);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error occurred while fetching subjects: ' + error);
            }
        });
    }
});
});



$(document).ready(function(){
    $('#Department_name2').on('change', function() {
        var selectedValue = $(this).val();
        $.ajax({
            type: "POST",
            url:baseurl+"Department_Wise/course",
            data: {selectedValue : selectedValue},
            success: function(response) {
                var responseData = JSON.parse(response);
                var dropdownOptions = {'': 'Course Type'}; // Initial dropdown options
                // Loop through the response data and add each course type to the dropdown options
                for (var i = 0; i < responseData.length; i++) {
                    var course = responseData[i];
                    dropdownOptions[course.CourseType] = course.CourseType;
                }
                // Update the dropdown with the new options
                $('#Course_type').empty(); // Clear existing options
                $.each(dropdownOptions, function(key, value) {
                    $('#Course_type').append($("<option></option>").attr("value", key).text(value));
                });
            },
            error: function(xhr, status, error) {
                // Handle error response here
                console.error('Error occurred while fetching courses.');
            }
        });
    });
});
    

$(document).ready(function(){
    $('#Department_name2').on('change', function() {
        fetchCourses();
    });

    $('#Course_type').on('change', function() {
        fetchCourses();
    });

    function fetchCourses() {
        var department = $('#Department_name2').val();
        var courseType = $('#Course_type').val();

        $.ajax({
            type: "POST",
            url: baseurl+"Department_Wise/course_code",
            data: {
                department: department,
                courseType: courseType
            },
            success: function(response) {
                var responseData = JSON.parse(response);
                $('#CourseCode').empty(); // Clear existing options
                $('#CourseCode').append($('<option></option>').attr('value', '').text('Select Course Code'));
                $.each(responseData, function(index, course) {
                    $('#CourseCode').append($('<option></option>').attr('value', course.CourseCode).text(course.CourseCode));
                });
            },
            error: function(xhr, status, error) {
                console.error('Error occurred while fetching courses.');
            }
        });
    }



});


$(document).ready(function() {
    $('#Department_name2, #Course_type').on('change', function() {
        fetchCourses();
    });

    function fetchCourses() {
        var department = $('#Department_name2').val();
        var courseType = $('#Course_type').val();

        $.ajax({
            type: "POST",
            url: baseurl + "Department_Wise/Section_Batch1",
            data: {
                Department: department,
                courseType: courseType
            },
            success: function(response) {
                try {
                    var responseData = JSON.parse(response);
                    var dropdownOptions = { '': 'Select Batch' };

                    responseData.forEach(function(subject) {
                        dropdownOptions[subject.Batch] = subject.Batch;
                    });

                    $('#Batch1').empty();


                    $.each(dropdownOptions, function(key, value) {
                        $('#Batch1').append($("<option></option>").attr("value", key).text(value));
                    });
                } catch (e) {
                    console.error('Error parsing response: ' + e);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error occurred while fetching subjects: ' + error);
            }
        });
    }
});


$(document).ready(function() {
    $('#Department_name2, #Course_type , #Batch1').on('change', function() {
        fetchCourses();
    });

    function fetchCourses() {
        var department = $('#Department_name2').val();
        var courseType = $('#Course_type').val();
        var Batch = $('#Batch1').val();

        $.ajax({
            type: "POST",
            url: baseurl + "Department_Wise/Section0",
            data: {
                Department: department,
                courseType: courseType,
                batch: Batch
            },
            success: function(response) {
                try {
                    var responseData = JSON.parse(response);
                    var dropdownOptions = { '': 'Section' };
             

                    responseData.forEach(function(subject) {
                        dropdownOptions[subject.Section] = subject.Section;
           
                    });

                    $('#Section1').empty();
              

                    $.each(dropdownOptions, function(key, value) {
                        $('#Section1').append($("<option></option>").attr("value", key).text(value));
                    });

               
                } catch (e) {
                    console.error('Error parsing response: ' + e);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error occurred while fetching subjects: ' + error);
            }
        });
    }
});







$(document).ready(function() {

    // var Institution_name = $("#Institution_name").val();
    var instname = $("#Institution_name").val();
    $.ajax({
        type: "POST",
        url: baseurl + "Department_Wise/get_departs",
        data : {
            instname: instname
        },
        success: function(response) {
            var responseData = JSON.parse(response);
            var dropdownOptions = {'': 'Select Department'}; // Initial dropdown options

            // Loop through the response data and add each department to the dropdown options
            $.each(responseData, function(index, department) {
                dropdownOptions[department.DepartmentName] = department.DepartmentName;
            });

            // Update the dropdown with the new options
            $('#Department_name2').empty(); // Clear existing options
            $.each(dropdownOptions, function(key, value) {
                $('#Department_name2').append($("<option></option>").attr("value", key).text(value));
            });
        },
        error: function(xhr, status, error) {
            console.error('Error occurred while fetching departments.');
        }
    });
});




$(document).ready(function () {
    $("#Department_name2").on("change", function () {
        var selectedValue = $(this).val(); // Get the selected value
        
        $.ajax({
            type: "POST",
            url: baseurl + "Department_Wise/get_Hod",
            data: { selectedValue: selectedValue }, 
            dataType: "json", 
            success: function (response) {
               
                    var Hod_name = response[0]; 
                    var icode = Hod_name.Hod_Name;
                    $('#Hod').val(icode);
                   
                }, 
          
            error: function (xhr, status, error) {
                // Handle error response here
                console.error('Error occurred while sending selected value to the controller.');
            }
        });
    });
});




$(document).ready(function() {
    $('#wizard-form1').submit(function(event) {
        event.preventDefault(); // Prevent default form submission

        // Serialize form data
        var formData = $(this).serialize();

        // AJAX request
        $.ajax({
            type: 'POST',
            url: baseurl+'Department_Wise/add_Staff1',
            data: formData,
            dataType: 'json', // Expect JSON response
            success: function(response) {
                if (response == 1) {
                    Swal.fire({
                        icon: "success",
                        title: "Success!",
                        text: "Successfully Assigned The Staff..!.",
                        // showCancelButton: true,
                        confirmButtonText: "OK",
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = baseurl + "Department_Wise";
                        }
                    });
                } else if (response == 'true') {
                    Swal.fire({
                        icon: "error",
                        title: "Error!",
                        text: "Already This Staff Assigned..!.",
                        // showCancelButton: true,
                        confirmButtonText: "OK",
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = baseurl + "Department_Wise";
                        }
                    });
                }
            },
            error: function(xhr, status, error) {
                // Handle error
                console.error(xhr.responseText);
                // Optionally show error message
            }
        });
    });
});
$(document).ready(function() {
    var departmentName = $("#Department_name0011").val();

    function fetchCourseTypes(departmentName) {
        $.ajax({
            type: "POST",
            url: baseurl + "Department_Wise/Course_type1",
            data: { department_name: departmentName },
            dataType: "json",
            success: function(response) {
                var dropdownOptions = { "": "Select Course Type" };

                $.each(response, function(index, item) {
                    dropdownOptions[item.Course_type] = item.Course_type;
                });

                $('#Course_type223').empty();
                $.each(dropdownOptions, function(key, value) {
                    $('#Course_type223').append($('<option></option>').attr('value', key).text(value));
                });

                var defaultCourseType = $('#Course_type223').val();
                fetchBatches(defaultCourseType, departmentName);
            },
            error: function(xhr, status, error) {
                console.error('Error occurred while fetching course types.');
            }
        });
    }

    function fetchBatches(courseType, departmentName) {
        $.ajax({
            type: "POST",
            url: baseurl + "Department_Wise/get_section11",
            data: { courseType: courseType, department_name: departmentName },
            success: function(response) {
                var responseData = JSON.parse(response);
                var batchOptions = { "": "Select Batch" };

                $.each(responseData, function(index, Batch) {
                    batchOptions[Batch.Batch] = Batch.Batch;
                });

                $("#Batch23").empty();
                $.each(batchOptions, function(key, value) {
                    $("#Batch23").append($('<option></option>').attr('value', key).text(value));
                });

                var defaultBatch = $('#Batch23').val();
                fetchSectionsForBatch(courseType, departmentName, defaultBatch);
            },
            error: function(xhr, status, error) {
                console.error('Error occurred while fetching batches.');
            }
        });
    }

    function fetchSectionsForBatch(courseType, departmentName, Batch) {
        $.ajax({
            type: "POST",
            url: baseurl + "Student_Timetable/Get_semasters",
            data: { courseType: courseType, department_name: departmentName, Batch: Batch },
            success: function(response) {
                var responseData = JSON.parse(response);
                var sectionOptions = { "": "Select Semester" };

                $.each(responseData, function(index, Semester) {
                    sectionOptions[Semester.Semester] = Semester.Semester;
                });

                $("#get_Semesters1").empty();
                $.each(sectionOptions, function(key, value) {
                    $("#get_Semesters1").append($('<option></option>').attr('value', key).text(value));
                });

                var defaultSemester = $('#get_Semesters1').val();
                fetchSectionsForSemester(courseType, departmentName, Batch, defaultSemester);
            },
            error: function(xhr, status, error) {
                console.error('Error occurred while fetching semesters.');
            }
        });
    }

    function fetchSectionsForSemester(courseType, departmentName, Batch, Semester) {
        $.ajax({
            type: "POST",
            url: baseurl + "Student_Timetable/Section23",
            data: { courseType: courseType, department_name: departmentName, Batch: Batch, Semester: Semester },
            success: function(response) {
                var responseData = JSON.parse(response);
                var sectionOptions = { "": "Select Section" };

                $.each(responseData, function(index, section) {
                    sectionOptions[section.Class_Section] = section.Class_Section;
                });

                $("#Section233").empty();
                $.each(sectionOptions, function(key, value) {
                    $("#Section233").append($('<option></option>').attr('value', key).text(value));
                });

                var defaultSection = $('#Section233').val();
                fetchTimetable(departmentName, courseType, defaultSection, Batch, Semester);
            },
            error: function(xhr, status, error) {
                console.error('Error occurred while fetching sections.');
            }
        });
    }

    function fetchTimetable(departmentName, courseType, section, Batch, Semester) {
        $.ajax({
            type: "POST",
            url: baseurl + "Department_Wise/get_timetable1",
            data: { department_name: departmentName, courseType: courseType, section: section, Batch: Batch, Semester: Semester },
            dataType: "json",
            success: function(response) {
                // Clear existing timetable data
                $('#timetableTable tbody').find('td:not(:first-child)').empty();
                
                // Populate timetable data
                $.each(response, function(index, item) {
                    var dayIndex = item.Dayss.replace('Day ', '');
                    var hours = item.Hours;
                    
                    $('#timetableTable tbody tr[data-day="' + dayIndex + '"]').find('td').each(function(hourIndex) {
                        if (hourIndex > 0) { // Skip the first column (Day column)
                            var hourKey = 'Hour_' + hourIndex;
                            $(this).html(hours[hourKey]);
                        }
                    });
                });
            },
            error: function(xhr, status, error) {
                console.error('Error occurred while fetching timetable data.');
            }
        });
    }

    // Initial fetch based on departmentName if available
    if (departmentName) {
        fetchCourseTypes(departmentName);
    }

    // Event listeners for changes in select elements
    $("#Department_name001").change(function() {
        departmentName = $(this).val();
        fetchCourseTypes(departmentName);
    });

    $("#Course_type223").change(function() {
        var selectedCourseType = $(this).val();
        fetchBatches(selectedCourseType, departmentName);
    });

    $("#Batch23").change(function() {
        var selectedCourseType = $('#Course_type223').val();
        var selectedBatch = $(this).val();
        fetchSectionsForBatch(selectedCourseType, departmentName, selectedBatch);
    });

    $("#get_Semesters1").change(function() {
        var selectedCourseType = $('#Course_type223').val();
        var selectedBatch = $('#Batch23').val();
        var selectedSemester = $(this).val();
        fetchSectionsForSemester(selectedCourseType, departmentName, selectedBatch, selectedSemester);
    });

    $("#Section233").change(function() {
        var selectedCourseType = $('#Course_type223').val();
        var selectedBatch = $('#Batch23').val();
        var selectedSemester = $('#get_Semesters1').val();
        var selectedSection = $(this).val();
        fetchTimetable(departmentName, selectedCourseType, selectedSection, selectedBatch, selectedSemester);
    });
});


$(document).ready(function() {
    $('#Institution_name,#Department_name2, #Course_type').on('change', function() {
        fetchCourses();
    });

    function fetchCourses() {
        var Institution_name = $('#Institution_name').val();
        var department = $('#Department_name2').val();
        var courseType = $('#Course_type').val();

        $.ajax({
            type: "POST",
            url: baseurl + "Department_Wise/Semaster",
            data: {
                Institution_name: Institution_name,
                Department: department,
                courseType: courseType
                
            },
            success: function(response) {
                try {
                    var responseData = JSON.parse(response);
                    var dropdownOptions = { '': 'Select Semester' };
             

                    responseData.forEach(function(subject) {
                        dropdownOptions[subject.Semester] = subject.Semester;
           
                    });

                    $('#Semesters').empty();
              

                    $.each(dropdownOptions, function(key, value) {
                        $('#Semesters').append($("<option></option>").attr("value", key).text(value));
                    });

               
                } catch (e) {
                    console.error('Error parsing response: ' + e);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error occurred while fetching subjects: ' + error);
            }
        });
    }
});