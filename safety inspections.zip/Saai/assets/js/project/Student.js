$(document).ready(function () {
	// Hide all stages except the first one
	$(".stage").not("#stage1").hide();

	// Function to show next stage
	$(".next").click(function () {
		var currentStage = $(this).closest(".stage");
		currentStage.hide();
		currentStage.next().show();
	});

	// Function to show previous stage
	$(".previous").click(function () {
		var currentStage = $(this).closest(".stage");
		currentStage.hide();
		currentStage.prev().show();
	});

	$(document).ready(function () {
		$("#education-level").change(function () {
			var educationLevel = $(this).val();
			if (educationLevel === "pg") {
				$(".final-info input")
					.prop("disabled", false)
					.prop("required", true)
					.prop("readonly", false);
			} else {
				$(".final-info input")
					.prop("disabled", true)
					.prop("required", false)
					.prop("readonly", true);
			}
		});
	});
});

//sakthi

$(document).ready(function () {
	$.ajax({
		type: "POST",
		url: baseurl + "Student/get_instution",
		success: function (response) {
			var responseData = JSON.parse(response);
			// alert(responseData);
			var dropdownOptions = { "": "Select Instution" }; // Initial dropdown options
			// Loop through the response data and add each district to the dropdown options
			for (var i = 0; i < responseData.length; i++) {
				var IName = responseData[i];
				dropdownOptions[IName.InstutionName] = IName.InstutionName;
			}
			// Update the dropdown with the new options
			$("#Inst_name_1").empty(); // Clear existing options
			$.each(dropdownOptions, function (key, value) {
				$("#Inst_name_1").append(
					$("<option></option>").attr("value", key).text(value)
				);
			});
		},
		error: function (xhr, status, error) {
			// Handle error response here
			console.error(
				"Error occurred while sending selected value to the controller."
			);
		},
	});
});


$(document).ready(function () {
    $("#Inst_name_1").on("change", function () {
        var selectedValue = $(this).val(); // Get the selected value
        
        $.ajax({
            type: "POST",
            url: baseurl + "Student/Inst_Code",
            data: { selectedValue: selectedValue }, 
            dataType: "json", 
            success: function (response) {
               
                    var firstInstution = response[0]; 
                    var icode = firstInstution.InstutionName_Code;
                    $('#Inst_codes').val(icode);
                   
                }, 
          
            error: function (xhr, status, error) {
                // Handle error response here
                console.error('Error occurred while sending selected value to the controller.');
            }
        });
    });
});



$(document).ready(function() {
    $(document).on("change", "#Inst_name_1", function() {
        var InstutionName = $(this).val(); // Get the selected value

        $.ajax({
            type: "POST",
            url: baseurl + "Student/get_staff_depat",
            data: { 
                InstutionName: InstutionName,
            }, 

            success: function(response) {

                var responseData = JSON.parse(response);
			var dropdownOptions = { "": "Select Department" }; // Initial dropdown options
			// Loop through the response data and add each district to the dropdown options
			for (var i = 0; i < responseData.length; i++) {
				var IName = responseData[i];
				dropdownOptions[IName.DepartmentName] = IName.DepartmentName;
			}
			// Update the dropdown with the new options
			$("#Department_Name11").empty(); // Clear existing options
			$.each(dropdownOptions, function (key, value) {
				$("#Department_Name11").append(
					$("<option></option>").attr("value", key).text(value)
				);
			});
            },
            error: function(xhr, status, error) {
                console.error('Error occurred while sending selected value to the controller.');
            }
        });
    });
});


                            //  course_type

		 $(document).ready(function(){
        $('#Department_Name11').on('change', function() {
            var selectedValue = $(this).val();
            $.ajax({
                type: "POST",
                url:baseurl+"Student/course",
                data: {selectedValue : selectedValue},
                success: function(response) {
                    var responseData = JSON.parse(response);
                    var dropdownOptions = {'': 'Course Type'}; // Initial dropdown options
                    // Loop through the response data and add each course type to the dropdown options
                    for (var i = 0; i < responseData.length; i++) {
                        var course = responseData[i];
                        dropdownOptions[course.CourseType] = course.CourseType;
                    }
                    // Update the dropdown with the new options
                    $('#Course_type').empty(); // Clear existing options
                    $.each(dropdownOptions, function(key, value) {
                        $('#Course_type').append($("<option></option>").attr("value", key).text(value));
                    });
                },
                error: function(xhr, status, error) {
                    // Handle error response here
                    console.error('Error occurred while fetching courses.');
                }
            });
        });
    });



	$(document).ready(function(){
		$('#Inst_name_1, #Inst_codes, #Course_type').on('change', function() {
			fetchCourses();
		});
	
		function fetchCourses() {
			var department = $('#Inst_name_1').val();
			var instCode = $('#Inst_codes').val();
			var courseType = $('#Course_type').val();
	
			$.ajax({
				type: "POST",
				url: baseurl + "Student/Semaster",
				data: {
					Inst_name_1: department,
					Inst_codes: instCode,
					courseType: courseType
				},
				success: function(response) {
					var responseData = JSON.parse(response);

					var dropdownOptions = { "": "Select Semester" }; // Initial dropdown options


					for (var i = 0; i < responseData.length; i++) {
                        var semester = responseData[i];
                        dropdownOptions[semester.Semester] = semester.Semester;
                    }
                    // Update the dropdown with the new options
                  

				
					$('#Semester').empty(); // Clear existing options
 
					$.each(dropdownOptions, function(key, value) {
                        $('#Semester').append($("<option></option>").attr("value", key).text(value));
                    });
					
				},
				
				error: function(xhr, status, error) {
					console.error('Error occurred while fetching courses.');
				}
			});
		}
	});
	
	$(document).ready(function(){
		$('#Department_Name11, #Course_type').on('change', function() {
			fetchCourses();
		});
	
		function fetchCourses() {
			var department = $('#Department_Name11').val();
			var courseType = $('#Course_type').val();
	
			$.ajax({
				type: "POST",
				url: baseurl + "Student/Course_Name",
				data: {
					department: department,
					courseType: courseType
				},
				success: function(response) {
					var responseData = JSON.parse(response);
	
					var dropdownOptions = { "": "Select CourseName" }; // Initial dropdown options
	
					for (var i = 0; i < responseData.length; i++) {
						var course = responseData[i];
						dropdownOptions[course.CourseName] = course.CourseName;
					}
	
					$('#Course_name').empty(); // Clear existing options
	
					$.each(dropdownOptions, function(key, value) {
						$('#Course_name').append($("<option></option>").attr("value", key).text(value));
					});
				},
				error: function(xhr, status, error) {
					console.error('Error occurred while fetching courses.');
				}
			});
		}
	});
	

	$(document).ready(function(){
		$('#Department_Name11, #Course_type').on('change', function() {
			fetchCourses();
		});
	
		function fetchCourses() {
			var department = $('#Department_Name11').val();
			var courseType = $('#Course_type').val();
	
			$.ajax({
				type: "POST",
				url: baseurl + "Student/Section_Batch",
				data: {
					department: department,
					courseType: courseType
				},
				success: function(response) {
					var responseData = JSON.parse(response);
	
					var dropdownOptions = { "": "Select Section" }; 
					var Batch ={"" :"Select Batch"}
	
					for (var i = 0; i < responseData.length; i++) {
						var course = responseData[i];
						dropdownOptions[course.Section] = course.Section;
						           Batch[course.Batch] = course.Batch;
					}
	
					$('#Section').empty(); 
					$('#Batch').empty(); // Clear existing options
	
					$.each(dropdownOptions, function(key, value) {
						$('#Section').append($("<option></option>").attr("value", key).text(value));
					});
					
					$.each(Batch, function(key, value) {
						$('#Batch').append($("<option></option>").attr("value", key).text(value));
					});
				},
				error: function(xhr, status, error) {
					console.error('Error occurred while fetching courses.');
				}
			});
		}
	});


///report

	
	$(document).ready(function () {
		$('#Class-view2').hide();
		
		$("#get_Class_list1").on("click", function () {
			var InstitutionName = $("#Inst_name_1").val();
			var Inst_codes = $("#Inst_codes").val();
			var Department_Name = $("#Department_Name11").val();
			var Course_type = $("#Course_type").val();
			var Semester = $("#Semester").val();
			var Batch = $("#Batch").val();
			var Section = $("#Section").val();
		
			$.ajax({       
				type: "POST",
				url: baseurl + "Student/get_Class_wise",
				data: {
					InstitutionName: InstitutionName,
					Inst_codes: Inst_codes,
					Department_Name: Department_Name,
					Course_type: Course_type,
					Semester: Semester,
					Batch: Batch,
					Section: Section,
				},
				
	success: function (response) {
		try {
			var responseData = JSON.parse(response);


			$('#Class_stud1').empty(); // Clear existing table rows
			$.each(responseData.reports, function(index, item) {

				$('#Class-view2').show();
				
				var row = `<tr>
	<td>${index + 1}</td>
    <td>${item.Student_Id}</td>
    <td>${item.name}</td>
    <td>${item.DepartmentName_1}</td>
    <td>${item.CourseType_1}</td>
    <td>${item.Semester_1}</td>
    <td>${item.Batch_1}</td>
    <td>${item.Section_1}</td>
    <td>${item.father_name}</td>
	<td>${item.mother_name}</td>
    <td>${item.InstitutionName_1}</td>
    <td>${item.Institutioncode_1}</td>
    <td>${item.CourseName_1}</td>
	<td>${item.course_type}</td>
    <td>${item.Exam_Reg_No}</td>
    <td>${item.initial}</td>
    <td>${item.dob}</td>
    <td>${item.place_of_birth}</td>
    <td>${item.mother_tongue}</td>
    <td>${item.father_occupation}</td>
    <td>${item.father_income}</td>
    <td>${item.blood_group}</td>
    <td>${item.mother_occupation}</td>
    <td>${item.mother_income}</td>
    <td>${item.aadhar_card_no}</td>
    <td>${item.mobile_no}</td>
    <td>${item.alternate_mobile_no}</td>
    <td>${item.stu_mobile_number}</td>
    <td>${item.email_id}</td>
    <td>${item.first_language}</td>
    <td>${item.parents}</td>
    <td>${item.religion}</td>
    <td>${item.community}</td>
    <td>${item.caste}</td>
    <td>${item.guardian_name}</td>
    <td>${item.extra_curricular_activities}</td>
    <td>${item.physical_disability}</td>
    <td>${item.volunteers}</td>
    
    <td>${item.gender}</td>
    <td>${item.per_addr_pincode}</td>
    <td>${item.per_addr_post_office}</td>
    <td>${item.per_addr_district}</td>
    <td>${item.per_addr_state}</td>
    <td>${item.communi_addr_pincode}</td>
    <td>${item.communi_addr_post_office}</td>
    <td>${item.communi_addr_district}</td>
    <td>${item.communi_addr_state}</td>
    <td>${item.PerAddr1}</td>
    <td>${item.PerAddr2}</td>
    <td>${item.ComAddr1}</td>
    <td>${item.ComAddr2}</td>
    <td>${item.SchoolName}</td>
    <td>${item.Sub1Name}</td>
    <td>${item.Sub1Mark}</td>
    <td>${item.Sub2Name}</td>
    <td>${item.Sub2Mark}</td>
    <td>${item.Sub3Name}</td>
    <td>${item.Sub3Mark}</td>
    <td>${item.Sub4Name}</td>
    <td>${item.Sub4Mark}</td>
    <td>${item.Sub5Name}</td>
    <td>${item.Sub5Mark}</td>
    <td>${item.Sub6Name}</td>
    <td>${item.Sub6Mark}</td>
    <td>${item.HSCMark}</td>
    <td>${item.HSCMarkPer}</td>
    <td>${item.MonthAndYearOfPass}</td>
    <td>${item.StudiedGroup}</td>
    <td>${item.HSCRollNo}</td>
    <td>${item.MediumofStudy}</td>
    <td>${item.TotalMaxMark}</td>
    <td>${item.EMISNo}</td>
    <td>${item.AadharCard}</td>
    <td>${item.BankPassBook}</td>
    <td>${item.CommunityCertif}</td>
    <td>${item.TransferCertif}</td>
    <td>${item.XthMarkSheet}</td>
    <td>${item.XIthMarkSheet}</td>
    <td>${item.XIIthMarkSheet}</td>
    <td>${item.ExaminationPassed}</td>
    <td>${item.IFSCCode}</td>
    <td>${item.BankName}</td>
    <td>${item.BankAddress}</td>
    <td>${item.AccountNumber}</td>
    <td>${item.MICRCode}</td>
    <td>${item.StuDegr}</td>
    <td>${item.StuDegType}</td>
    <td>${item.YearofPassing}</td>
    <td>${item.UniversityName}</td>
    <td>${item.InstituionName}</td>
    <td>${item.StudiedMode}</td>
    <td>${item.PassPercent}</td>
    <td>${item.Specialization}</td>
    <td>${item.DateOfAdmission}</td>
    <td>${item.RollNo}</td>
    <td>${item.DepName}</td>
    <td>${item.DepCode}</td>
    <td>${item.CourseYear}</td>
    <td>${item.CourseNameSD}</td>
    <td>${item.CourseNameBD}</td>
    <td>${item.CourseCode}</td>
    <td>${item.BroSysStudyingStudied}</td>
    <td>${item.NameBroSys}</td>
    <td>${item.ModeOFTransport}</td>
    <td>${item.BoardingPoint}</td>
    <td>${item.ImageFileName}</td>
    <td>${item.ImageContentType}</td>
    <td>${item.ImageData}</td>
    <td>${item.Hostel}</td>
    <td>${item.ScholarShip}</td>
    <td>${item.ScholarShipType}</td>
    <td>${item.CharityScholarship}</td>
    <td>${item.CharityAmount}</td>
    <td>${item.ManagementScholarship}</td>
    <td>${item.Quota}</td>
    <td>${item.Concession}</td>
    <td>${item.Remark}</td>
    <td>${item.Referredby}</td>
    <td>${item.TCReceivedDate}</td>
    <td>${item.DocEnclosed}</td>
    <td>${item.DocNotEnclosed}</td>
    <td>${item.InstitutCode}</td>
    <td>${item.Status}</td>
    <td>${item.LastDate}</td>
    <td>${item.Reasonforleaving}</td>

			

			</tr>`;
				
				$('#Class_stud1').append(row);
			});
		} catch (error) {
			console.error("Error parsing response:", error);
		}
	},
	error: function (xhr, status, error) {
		console.error("AJAX request failed:", status, error);
		// Optionally handle error display to the user
	}
});
});

// Function to escape HTML characters
function escapeHtml(unsafe) {
return typeof unsafe === 'string'
	? unsafe.replace(/[&<"']/g, function(m) {
		switch (m) {
			case '&':
				return '&amp;';
			case '<':
				return '&lt;';
			case '"':
				return '&quot;';
			case "'":
				return '&#39;';
			default:
				return m;
		}
	})
	: unsafe;
}
});


                                                    //  Department_wise


	
													$(document).ready(function () {
														$('#Class-view23').hide();
														
														$("#get_Department_list2").on("click", function () {
															var InstitutionName = $("#Inst_name_1").val();
															var Inst_codes = $("#Inst_codes").val();
															var Department_Name = $("#Department_Name11").val();
															var Course_type = $("#Course_type").val();
														
														
															$.ajax({       
																type: "POST",
																url: baseurl + "Student/get_Department_wise",
																data: {
																	InstitutionName: InstitutionName,
																	Inst_codes: Inst_codes,
																	Department_Name: Department_Name,
																	Course_type: Course_type,
																
																},
																
													success: function (response) {
														try {
															var responseData = JSON.parse(response);
												
												
															$('#Class_stud12').empty(); // Clear existing table rows
												alert("dgqbehj");
															$.each(responseData.reports, function(index, item) {
												
																$('#Class-view23').show();
																
																var row = `<tr>
													<td>${index + 1}</td>
													<td>${item.Student_Id}</td>
													<td>${item.name}</td>
													<td>${item.DepartmentName_1}</td>
													<td>${item.CourseType_1}</td>
													<td>${item.Semester_1}</td>
													<td>${item.Batch_1}</td>
													<td>${item.Section_1}</td>
													<td>${item.father_name}</td>
													<td>${item.mother_name}</td>
													<td>${item.InstitutionName_1}</td>
													<td>${item.Institutioncode_1}</td>
													<td>${item.CourseName_1}</td>
													<td>${item.course_type}</td>
													<td>${item.Exam_Reg_No}</td>
													<td>${item.initial}</td>
													<td>${item.dob}</td>
													<td>${item.place_of_birth}</td>
													<td>${item.mother_tongue}</td>
													<td>${item.father_occupation}</td>
													<td>${item.father_income}</td>
													<td>${item.blood_group}</td>
													<td>${item.mother_occupation}</td>
													<td>${item.mother_income}</td>
													<td>${item.aadhar_card_no}</td>
													<td>${item.mobile_no}</td>
													<td>${item.alternate_mobile_no}</td>
													<td>${item.stu_mobile_number}</td>
													<td>${item.email_id}</td>
													<td>${item.first_language}</td>
													<td>${item.parents}</td>
													<td>${item.religion}</td>
													<td>${item.community}</td>
													<td>${item.caste}</td>
													<td>${item.guardian_name}</td>
													<td>${item.extra_curricular_activities}</td>
													<td>${item.physical_disability}</td>
													<td>${item.volunteers}</td>
													
													<td>${item.gender}</td>
													<td>${item.per_addr_pincode}</td>
													<td>${item.per_addr_post_office}</td>
													<td>${item.per_addr_district}</td>
													<td>${item.per_addr_state}</td>
													<td>${item.communi_addr_pincode}</td>
													<td>${item.communi_addr_post_office}</td>
													<td>${item.communi_addr_district}</td>
													<td>${item.communi_addr_state}</td>
													<td>${item.PerAddr1}</td>
													<td>${item.PerAddr2}</td>
													<td>${item.ComAddr1}</td>
													<td>${item.ComAddr2}</td>
													<td>${item.SchoolName}</td>
													<td>${item.Sub1Name}</td>
													<td>${item.Sub1Mark}</td>
													<td>${item.Sub2Name}</td>
													<td>${item.Sub2Mark}</td>
													<td>${item.Sub3Name}</td>
													<td>${item.Sub3Mark}</td>
													<td>${item.Sub4Name}</td>
													<td>${item.Sub4Mark}</td>
													<td>${item.Sub5Name}</td>
													<td>${item.Sub5Mark}</td>
													<td>${item.Sub6Name}</td>
													<td>${item.Sub6Mark}</td>
													<td>${item.HSCMark}</td>
													<td>${item.HSCMarkPer}</td>
													<td>${item.MonthAndYearOfPass}</td>
													<td>${item.StudiedGroup}</td>
													<td>${item.HSCRollNo}</td>
													<td>${item.MediumofStudy}</td>
													<td>${item.TotalMaxMark}</td>
													<td>${item.EMISNo}</td>
													<td>${item.AadharCard}</td>
													<td>${item.BankPassBook}</td>
													<td>${item.CommunityCertif}</td>
													<td>${item.TransferCertif}</td>
													<td>${item.XthMarkSheet}</td>
													<td>${item.XIthMarkSheet}</td>
													<td>${item.XIIthMarkSheet}</td>
													<td>${item.ExaminationPassed}</td>
													<td>${item.IFSCCode}</td>
													<td>${item.BankName}</td>
													<td>${item.BankAddress}</td>
													<td>${item.AccountNumber}</td>
													<td>${item.MICRCode}</td>
													<td>${item.StuDegr}</td>
													<td>${item.StuDegType}</td>
													<td>${item.YearofPassing}</td>
													<td>${item.UniversityName}</td>
													<td>${item.InstituionName}</td>
													<td>${item.StudiedMode}</td>
													<td>${item.PassPercent}</td>
													<td>${item.Specialization}</td>
													<td>${item.DateOfAdmission}</td>
													<td>${item.RollNo}</td>
													<td>${item.DepName}</td>
													<td>${item.DepCode}</td>
													<td>${item.CourseYear}</td>
													<td>${item.CourseNameSD}</td>
													<td>${item.CourseNameBD}</td>
													<td>${item.CourseCode}</td>
													<td>${item.BroSysStudyingStudied}</td>
													<td>${item.NameBroSys}</td>
													<td>${item.ModeOFTransport}</td>
													<td>${item.BoardingPoint}</td>
													<td>${item.ImageFileName}</td>
													<td>${item.ImageContentType}</td>
													<td>${item.ImageData}</td>
													<td>${item.Hostel}</td>
													<td>${item.ScholarShip}</td>
													<td>${item.ScholarShipType}</td>
													<td>${item.CharityScholarship}</td>
													<td>${item.CharityAmount}</td>
													<td>${item.ManagementScholarship}</td>
													<td>${item.Quota}</td>
													<td>${item.Concession}</td>
													<td>${item.Remark}</td>
													<td>${item.Referredby}</td>
													<td>${item.TCReceivedDate}</td>
													<td>${item.DocEnclosed}</td>
													<td>${item.DocNotEnclosed}</td>
													<td>${item.InstitutCode}</td>
													<td>${item.Status}</td>
													<td>${item.LastDate}</td>
													<td>${item.Reasonforleaving}</td>
												
															
												
															</tr>`;
																
																$('#Class_stud12').append(row);
															});
														} catch (error) {
															console.error("Error parsing response:", error);
														}
													},
													error: function (xhr, status, error) {
														console.error("AJAX request failed:", status, error);
														// Optionally handle error display to the user
													}
												});
												});
												
												// Function to escape HTML characters
												function escapeHtml(unsafe) {
												return typeof unsafe === 'string'
													? unsafe.replace(/[&<"']/g, function(m) {
														switch (m) {
															case '&':
																return '&amp;';
															case '<':
																return '&lt;';
															case '"':
																return '&quot;';
															case "'":
																return '&#39;';
															default:
																return m;
														}
													})
													: unsafe;
												}
												});





												
$(document).ready(function(){
	$("#class_wise_student_list").on("click",function(){

		var Institute = $("#InstutionName").val();
		var Course_type = $("#Course_type").val();
		var DepartmentName = $("#DepartmentName").val();
		var Batch = $("#Batch").val();
		var Course_name = $("#Course_name").val();
		var Section = $("#Section").val();

		$.ajax({
            url: baseurl + "Student/class_wise_student",
            method: "POST",
            data: {
                Institute: Institute,
                Course_type: Course_type,
                DepartmentName: DepartmentName,
                Batch: Batch,
                Course_name: Course_name,
                Section: Section
            },
            success: function(response) {

				var responseData = JSON.parse(response);

				var data = responseData.get_class_wise_student;


				$.each(data, function(index, item) {
					var row = `<tr>
					<td>${index + 1}</td>
					<td>${item.DepartmentName_1}</td>
					<td>${item.Student_Id}</td>
					<td>${item.name}</td>
					<td>${item.Semester}</td>
					<td>${item.stu_mobile_number}</td>
					<td>${item.email_id}</td>
					<td>
					<a  id="Student_view" data-id='${item.Student_Id}'><i class='fas fa-eye text-info'></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
					 <a  href="edit/${item.Student_Id}" id="Edit_Staff" data-id='${item.Student_Id}' <i class='fas fa-edit text-primary' ></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
					<a id="Delete_Staff"  data-id='${item.Student_Id}' <i class='fas fa-trash text-danger'></i></a>
				</td>	
				</tr>`;

					$("#class_wise_student").append(row);
				});

 
			}

	})
	// Close the modal when the close button is clicked
	$("#close_pop").on("click", function() {
		$("#class_wise_student").modal("hide");

		});
})
})


$(document).ready(function() {
    // When a file is selected in the file input
    $('#upload_image').change(function() {
        var file = this.files[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function(e) {
                // Update the src attribute of the img element to show the new image
                $('#current_image').attr('src', e.target.result);
            }
            reader.readAsDataURL(file);
        }
    });
});


$(document).on("click", "#Student_view", function(){
	var Student_id = $(this).data("id");

	$.ajax({
		type: "POST",
        url: baseurl + "Student/view_Student",
        data: {
            Student_id: Student_id
        },
        success: function (response) {
            var responseData = JSON.parse(response);
			var data = responseData.Student_data;
			
            $("#student_view_modal").modal("show");

			
            $("#view_student_id").val(data.Student_Id);
			$("#view_Student_name").val(data.name);
			$("#view_batch").val(data.Batch);
			$("#view_semester").val(data.Semester_1);
			$("#view_course").val(data.CourseName_1);
			$("#view_coursetypet").val(data.CourseType_1);
			$("#view_dob").val(data.dob);
			$("#view_aadhar").val(data.AadharCard);
			$("#view_blood_group").val(data.blood_group);
			$("#view_department").val(data.DepartmentName_1);
			$("#view_address").val(data.Address);
			$("#view_Mobile").val(data.stu_mobile_number);
		    $("#view_image").attr("src", baseurl + "uploads/Student_Profile/" + data.Profile);

        },
        error: function (xhr, status, error) {
		}
	
	})
})















